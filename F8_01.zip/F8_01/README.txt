F8_01 dataset and environment audit.
This run does not establish confidentiality, authentication, physical or human security.
Use reports/dataset_manifest.csv and reports/splits.json in subsequent F8 programs.
