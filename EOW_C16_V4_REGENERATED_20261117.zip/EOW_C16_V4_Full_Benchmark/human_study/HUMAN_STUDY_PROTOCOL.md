# Prospective human-observer calibration protocol (not yet executed)

**Do not recruit participants without applicable institutional ethics approval or documented exemption.**

1. Define a human-only inspection task and independently authenticated reference custody. State exactly what the participant may see.
2. Pre-register genuine vs wrong-partner decisions, separate fixed-mask alterations, viewing distance, print material, illumination, and physical alignment procedure.
3. Recruit consenting observers; assign pseudonymous IDs. Store consent separately and never include personal identifiers in shared research CSVs.
4. Randomize and counterbalance trial order, avoid training/test image leakage, record actual responses, response times, confidence and unusable presentations.
5. Separate participant-level training, validation and held-out test cohorts *before* fitting perceptual parameters. Also hold out source images.
6. Fit the observer model only to training humans; tune on validation; evaluate once on held-out humans and held-out images. Report calibration curves, Brier score, FAR, FRR, uncertainty and unusable rate.
7. The calibration command in this package currently performs **descriptive empirical aggregation only**, not model fitting. No real human data are supplied.
8. Label all digital/synthetic/physical/human results distinctly.
