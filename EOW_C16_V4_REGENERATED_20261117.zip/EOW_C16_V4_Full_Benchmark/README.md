# EOW_C16 V4 — Full benchmark and prospective human calibration

## Evidence status

**Full 546-image benchmark has NOT been run here:** the complete original dataset is not present in this package. C10's archived results contain counts and summary records, not the underlying 546 source images. The program refuses to claim 546 images if it cannot load 546 unique decodable images.

**Human calibration has NOT been run:** no real participant responses have been supplied. No synthetic decisions are presented as human data. The included eight-image smoke test is for execution checking only.

## Installation

`python -m pip install numpy pillow scikit-learn`

## Windows PowerShell: run the full 546-image benchmark

```powershell
python .\EOW_C16_V4.py benchmark `
  --dataset "D:\48\481\New Papers\Nature_Idea\Experiments\Data" `
  --output "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C16_V4_546" `
  --images 546 `
  --observers 100 `
  --repetitions 10 `
  --seed 20261116
```

The dataset is enumerated in sorted path order, unreadable and duplicate files are audited, and the first 546 unique decodable images are selected. This **does not verify** that the selected set is exactly the paper's 539 real plus seven synthetic images. Before using results in the paper, provide the definitive 546-file list with provenance and enforce it. The earlier C10 report identified 554 decodable files and excluded 510 `.mat` files; this script does not interpret `.mat` annotations. Do not conflate this subset with the benchmark until its membership is checked.

The program generates 546×9=4,914 optical stimuli, 4,914,000 synthetic decisions, held-out image classifier predictions, reconstruction checks, and an evidence report. For manageability, synthetic decisions are aggregated by image/condition (each represents 1,000 draws). The decision model is uncalibrated and is **not** human evidence. The optical distortions are simplified raster surrogates, not physically calibrated rendering. In particular shifts use periodic wrapping and should be replaced by realistic edge-filled registration before any physical fidelity claim.

## Prospective human study preparation

```powershell
python .\EOW_C16_V4.py human-template --output ".\human_study"
```

Complete the study protocol, obtain applicable ethics approval or exemption, and collect actual participant responses. Do not enter fabricated responses. At least 12 distinct consent-confirmed participants are required by the tool for descriptive analysis; this is a **software threshold, not a sample-size justification**.

## Empirical calibration, only after human data exist

```powershell
python .\EOW_C16_V4.py calibrate `
  --responses ".\human_study\HUMAN_RESPONSES_COMPLETED.csv" `
  --features "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C16_V4_546\stimulus_features.csv" `
  --output "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C16_V4_Human_Calibration" `
  --min-participants 12
```

This fits a regularized logistic observer model on **genuine participant decisions** with disjoint participant and image train/test partitions. It reports a held-out Brier score and individual held-out predictions. It does not claim psychophysical validity, and it will stop if the response dataset is inadequate. `--features` omitted: only empirical descriptive acceptance rates and participant-cluster bootstrap intervals are produced, with no fitted calibration.

## Scientific limitations

- The wrong-partner condition uses a different image's B share; it is a negative control, not automatically an attacker-feasible forgery.
- The fixed-mask modified B share flips 1% of binary-secret pixels while retaining A's random mask; it is a controlled diagnostic, not a proven attacker capability.
- The original-vs-wrong-partner classifier is supervised on digital condition labels, not human judgments.
- The paper's human-only trust boundary prohibits hidden original-image templates in the verifier; blind image features are used at inference.
- A successful digital discrimination benchmark does not prove issuer-to-optical binding or post-quantum authentication.
- The study is not complete until real printing, genuine human data, calibrated optics, and independent held-out validation are obtained.

References: Naor & Shamir https://doi.org/10.1007/BFb0053419 ; NIST FIPS 204 https://doi.org/10.6028/NIST.FIPS.204
