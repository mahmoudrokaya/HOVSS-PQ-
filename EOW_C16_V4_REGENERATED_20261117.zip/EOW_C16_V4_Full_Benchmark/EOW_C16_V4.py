#!/usr/bin/env python3
"""EOW C16 V4: full image benchmark, synthetic observer, prospective human calibration.
No simulated response is empirical evidence. Requires local original image dataset.
"""
import argparse,csv,hashlib,json,math,random,sys
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter,ImageOps
EXT={'.jpg','.jpeg','.png','.bmp','.tif','.tiff','.webp'}
CONDITIONS=['original_ideal','original_shift_1','original_shift_3','original_rotate_1deg','original_wrong_partner','fixed_modified_ideal','fixed_modified_shift_1','fixed_modified_blur','fixed_modified_ink_spread']
def savecsv(p,rows,cols):
 with open(p,'w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(rows)
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def image_files(root):
 return sorted((p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in EXT),key=lambda p:str(p).lower())
def read_img(p):
 im=Image.open(p);im=ImageOps.exif_transpose(im).convert('L').resize((128,128),Image.Resampling.LANCZOS)
 return np.asarray(im,dtype=np.uint8)
def bits(a):return (a<128).astype(np.uint8)
def shares(secret,rng):
 # Two subpixels per secret pixel: identical pairs for white, complementary for black.
 # OR output: white -> 1 black per pair; black -> 2 black per pair.
 mask=rng.integers(0,2,size=secret.shape,dtype=np.uint8)
 A=np.empty((secret.shape[0],secret.shape[1]*2),np.uint8)
 B=np.empty_like(A)
 A[:,0::2]=mask;A[:,1::2]=1-mask
 B[:,0::2]=mask^secret;B[:,1::2]=1-(mask^secret)
 return A,B,mask
def overlay(A,B):return np.maximum(A,B)
def render(binary):return Image.fromarray(np.uint8(255*(1-binary)),mode='L')
def features(im):
 x=np.asarray(im,dtype=np.float32)/255
 gx=np.abs(np.diff(x,axis=1));gy=np.abs(np.diff(x,axis=0))
 # No original secret, condition label, or expected-image comparator is available here.
 return [float(x.mean()),float(x.std()),float((x<.35).mean()),float((x>.65).mean()),float(gx.mean()),float(gy.mean()),float((gx>.4).mean()),float((gy>.4).mean()),float(np.abs(x[:,2:]-x[:,:-2]).mean()),float(np.abs(x[2:,:]-x[:-2,:]).mean())]
def distort(im,condition):
 if 'shift_1' in condition: return Image.new('L',im.size,255).paste(im,(1,0)) # handled below
 return im
def make_stimuli(A,B,Bwrong,Bmod):
 def composite(a,b):return render(overlay(a,b))
 def shift(b,dx):return np.roll(b,dx,axis=1)
 original=composite(A,B);modified=composite(A,Bmod)
 rot=render(overlay(A,np.asarray(render(B).rotate(1,resample=Image.Resampling.NEAREST,fillcolor=255))<128))
 # Binary array conversion for rotated B: True means ink
 ink=np.asarray(modified.filter(ImageFilter.MinFilter(3)))
 return {'original_ideal':original,'original_shift_1':composite(A,shift(B,1)),
 'original_shift_3':composite(A,shift(B,3)),'original_rotate_1deg':rot,
 'original_wrong_partner':composite(A,Bwrong),'fixed_modified_ideal':modified,
 'fixed_modified_shift_1':composite(A,shift(Bmod,1)),
 'fixed_modified_blur':modified.filter(ImageFilter.GaussianBlur(.9)),
 'fixed_modified_ink_spread':Image.fromarray(np.uint8(ink))}
def sigmoid(x):return 1/(1+np.exp(-np.clip(x,-35,35)))
def grouped_fit(rows,seed):
 # One held-out image at a time; class labels are condition labels used only in training.
 # Never call the resulting classifier human calibrated.
 try:from sklearn.linear_model import LogisticRegression
 except ImportError:raise SystemExit('Install scikit-learn: python -m pip install scikit-learn')
 subset=[r for r in rows if r['condition'] in ('original_ideal','original_wrong_partner')]
 X=np.array([[float(r['f'+str(i)]) for i in range(10)] for r in subset]);Y=np.array([int(r['condition']=='original_ideal') for r in subset]);G=np.array([r['image_id'] for r in subset]);scores=np.zeros(len(subset))
 for g in sorted(set(G)):
  tr=G!=g;te=~tr;mu=X[tr].mean(axis=0);sd=X[tr].std(axis=0);sd[sd<1e-7]=1
  clf=LogisticRegression(C=.1,random_state=seed,max_iter=500).fit((X[tr]-mu)/sd,Y[tr]);scores[te]=clf.predict_proba((X[te]-mu)/sd)[:,1]
 out=[{'image_id':r['image_id'],'condition':r['condition'],'truth_legitimate':int(y),'heldout_score':round(float(s),8),'heldout_prediction':int(s>=.5)} for r,y,s in zip(subset,Y,scores)]
 # Mann-Whitney AUC including ties
 pos=scores[Y==1];neg=scores[Y==0];auc=float(np.mean((pos[:,None]>neg[None,:])+.5*(pos[:,None]==neg[None,:])))
 tpr=float(np.mean(pos>=.5));tnr=float(np.mean(neg<.5))
 return out,{'auc':auc,'balanced_accuracy':(tpr+tnr)/2,'n_independent_images':len(set(G)),'n_stimuli':len(subset)}
def run_benchmark(a):
 root=Path(a.dataset);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 if not root.is_dir():raise SystemExit('Dataset directory missing: '+str(root))
 paths=image_files(root);audit=[];selected=[];seen=set()
 for p in paths:
  try:
   im=read_img(p);h=sha(p)
   if h in seen: audit.append({'path':str(p),'status':'DUPLICATE_SHA256','sha256':h});continue
   seen.add(h);selected.append((p,im,h))
  except Exception as e:audit.append({'path':str(p),'status':'UNREADABLE','reason':str(e)[:160]})
  if len(selected)==a.images:break
 if len(selected)!=a.images:
  savecsv(out/'dataset_audit.csv',audit,['path','status','sha256','reason'])
  raise SystemExit(f'Expected {a.images} decodable unique images, found {len(selected)}. No fabricated benchmark. See dataset_audit.csv.')
 rng=np.random.default_rng(a.seed);rows=[];severity=[];binary=[];manifest=[]
 # Precompute all shares to form wrong partners with independent masks and content.
 for p,im,h in selected:
  s=bits(im);A,B,mask=shares(s,rng)
  binary.append((s,A,B,mask))
 for i,(p,im,h) in enumerate(selected):
  s,A,B,mask=binary[i];other=binary[(i+1)%len(binary)][2]
  # Source alteration is controlled at binary-secret level: 1% flips in a fixed seeded region.
  s2=s.copy();n=max(1,round(s.size*a.alteration_fraction));indices=rng.choice(s.size,size=n,replace=False);s2.flat[indices]^=1
  Bmod=np.empty_like(B);Bmod[:,0::2]=mask^s2;Bmod[:,1::2]=1-(mask^s2)
  assert np.array_equal(np.sum(overlay(A,B).reshape(128,128,2),axis=2),1+s)
  assert np.array_equal(np.sum(overlay(A,Bmod).reshape(128,128,2),axis=2),1+s2)
  severity.append({'image_id':i,'binary_changed_pixels':n,'binary_severity':n/s.size,'original_reconstruction_pass':True,'fixed_mask_reconstruction_pass':True})
  stim=make_stimuli(A,B,other,Bmod)
  for cond,photo in stim.items():
   fs=features(photo);rows.append({'image_id':i,'source_path':str(p.relative_to(root)),'condition':cond,**{'f'+str(k):v for k,v in enumerate(fs)}})
  manifest.append({'image_id':i,'path':str(p.relative_to(root)),'sha256':h})
 savecsv(out/'stimulus_features.csv',rows,['image_id','source_path','condition']+['f'+str(k) for k in range(10)])
 savecsv(out/'alteration_severity.csv',severity,list(severity[0]))
 held,metric=grouped_fit(rows,a.seed);savecsv(out/'heldout_predictions.csv',held,list(held[0]))
 # Simulation-only observer responses: model is NOT calibrated; no privileged template.
 # Run with vectorized batches; default outputs per-stimulus aggregates, not ~5m individual rows.
 feats=np.array([[r['f'+str(k)] for k in range(10)] for r in rows]);contrast=feats[:,1];edge=feats[:,4]+feats[:,5]
 # arbitrary preregistered model coefficients, deliberately uncalibrated
 evidence=-.25+2.2*contrast+1.5*edge
 observers=np.random.default_rng(a.seed+101);bias=observers.normal(0,.45,size=a.observers);sens=np.exp(observers.normal(0,.2,size=a.observers));lapse=observers.uniform(.01,.08,size=a.observers)
 agg=[]
 for j,r in enumerate(rows):
  pr=lapse[:,None]/2+(1-lapse[:,None])*sigmoid((evidence[j]*sens[:,None]+bias[:,None])+observers.normal(0,.35,size=(a.observers,a.repetitions)))
  dec=observers.random((a.observers,a.repetitions))<pr
  agg.append({'image_id':r['image_id'],'condition':r['condition'],'synthetic_accepts':int(dec.sum()),'synthetic_trials':a.observers*a.repetitions,'synthetic_acceptance':float(dec.mean())})
 savecsv(out/'synthetic_observer_aggregates.csv',agg,list(agg[0]))
 conf={'experiment':'EOW_C16_V4','evidence_level':'DIGITAL_SIMULATION_ONLY','dataset_root':str(root),'images':len(selected),'conditions':len(CONDITIONS),'observers':a.observers,'repetitions':a.repetitions,'seed':a.seed,'synthetic_decisions':len(rows)*a.observers*a.repetitions,'heldout_classifier':metric,'uncalibrated_assumptions':{'observer_bias_normal_sd':.45,'observer_sensitivity_log_normal_sd':.2,'lapse_uniform':[.01,.08],'decision_noise_sd':.35,'evidence_coefficients':[-.25,2.2,1.5]},'physical_trials':0,'human_participants':0,'human_calibration':'NOT_PERFORMED','security_qualification':'NOT_ESTABLISHED','image_manifest':manifest,'excluded_files':audit}
 (out/'manifest.json').write_text(json.dumps(conf,indent=2),encoding='utf-8')
 (out/'evidence_report.md').write_text(f'''# EOW C16 V4 — Full digital benchmark\n\n**Evidence classification: synthetic digital simulation; no empirical human calibration.**\n\n- Images: {len(selected)} unique decodable images (input-order selected; audit manifest).\n- Optical stimuli: {len(rows)} ({len(CONDITIONS)} per image).\n- Synthetic decisions: {conf['synthetic_decisions']:,} ({a.observers} observers × {a.repetitions} repetitions per stimulus).\n- Leave-one-image-out supervised digital classifier ROC-AUC: {metric['auc']:.4f}; balanced accuracy: {metric['balanced_accuracy']:.4f}.\n- Fixed-mask alterations: {a.alteration_fraction:.2%} of binary pixels; digital reconstruction checks passed for all images.\n\n## Important limitations\n\nThe simulated observer parameters are assumed, not estimated from humans. The held-out classifier is supervised on synthetic condition labels and is not a human model. The altered secret is produced by controlled flips, not necessarily an attacker-feasible manipulation. The shift implementation uses periodic wrapping and is not a physical registration model; rotations/blur are illustrative raster operations. No issuer-to-optical authentication proof is supplied. The input selection is the first {a.images} decodable SHA256-unique images in sorted path order, not an externally verified real/synthetic provenance stratification.\n\n**Human data required:** use the separately provided prospective study templates and calibration command.\n''',encoding='utf-8')
 print(json.dumps({k:conf[k] for k in ['images','conditions','observers','repetitions','synthetic_decisions','heldout_classifier','human_calibration']},indent=2))
def calibrate(a):
 # Independent human responses required. Never synthesize or impute missing rows.
 rows=list(csv.DictReader(open(a.responses,newline='',encoding='utf-8-sig')))
 required={'participant_id','stimulus_id','image_id','condition','decision_accept','consent_confirmed'}
 if not rows or not required.issubset(rows[0]):raise SystemExit('Missing genuine participant responses or required columns: '+', '.join(sorted(required)))
 valid=[]
 for r in rows:
  if r['consent_confirmed'].lower() not in ('yes','true','1'):continue
  if r['decision_accept'] not in ('0','1'):continue
  if r['condition'] not in CONDITIONS:continue
  valid.append(r)
 people=sorted({r['participant_id'] for r in valid});out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 if len(people)<a.min_participants:raise SystemExit(f'Only {len(people)} genuine consent-confirmed participants; require >= {a.min_participants}. No calibration performed.')
 # Descriptive empirical rates, clustered bootstrap by participant (NOT claiming independent trials).
 random_gen=random.Random(a.seed);summ=[]
 for cond in CONDITIONS:
  rr=[r for r in valid if r['condition']==cond];pids=sorted(set(r['participant_id'] for r in rr));by={p:[int(r['decision_accept']) for r in rr if r['participant_id']==p] for p in pids}
  if not rr:continue
  vals=[]
  for _ in range(1000):
   sample=[random_gen.choice(pids) for _ in pids];seq=[v for pid in sample for v in by[pid]];vals.append(sum(seq)/len(seq))
  vals.sort();summ.append({'condition':cond,'empirical_acceptance':sum(int(r['decision_accept']) for r in rr)/len(rr),'responses':len(rr),'independent_participants':len(pids),'participant_cluster_ci_low':vals[24],'participant_cluster_ci_high':vals[975]})
 savecsv(out/'empirical_descriptive_rates.csv',summ,list(summ[0]))
 # Optional empirical calibration: train on disjoint participants AND images; evaluate held-out intersections.
 if a.features:
  try:from sklearn.linear_model import LogisticRegression
  except ImportError:raise SystemExit('Install scikit-learn to fit human calibration')
  fmap={(str(r['image_id']),r['condition']):np.array([float(r['f'+str(k)]) for k in range(10)]) for r in csv.DictReader(open(a.features,encoding='utf-8-sig'))}
  joined=[(r,fmap[(str(r['image_id']),r['condition'])]) for r in valid if (str(r['image_id']),r['condition']) in fmap]
  images=sorted(set(str(r['image_id']) for r,f in joined))
  if len(images)<8:raise SystemExit('At least eight images with actual human judgments required for held-out calibration')
  rg=np.random.default_rng(a.seed);pp=people.copy();ii=images.copy();rg.shuffle(pp);rg.shuffle(ii)
  testp=set(pp[:max(2,len(pp)//4)]);testi=set(ii[:max(2,len(ii)//4)])
  train=[(r,f) for r,f in joined if r['participant_id'] not in testp and str(r['image_id']) not in testi]
  test=[(r,f) for r,f in joined if r['participant_id'] in testp and str(r['image_id']) in testi]
  if len(train)<30 or len(test)<10:raise SystemExit('Insufficient non-overlapping participant AND image training/test responses')
  X=np.array([f for r,f in train]);Y=np.array([int(r['decision_accept']) for r,f in train]);
  if len(set(Y))<2:raise SystemExit('Human training responses include only one decision class')
  mu=X.mean(0);sd=X.std(0);sd[sd<1e-7]=1
  clf=LogisticRegression(C=.1,random_state=a.seed,max_iter=1000).fit((X-mu)/sd,Y)
  Xt=np.array([f for r,f in test]);yt=np.array([int(r['decision_accept']) for r,f in test]);pred=clf.predict_proba((Xt-mu)/sd)[:,1]
  records=[{'participant_id':r['participant_id'],'image_id':r['image_id'],'condition':r['condition'],'human_decision':int(r['decision_accept']),'predicted_human_acceptance':float(v)} for (r,f),v in zip(test,pred)]
  savecsv(out/'heldout_human_predictions.csv',records,list(records[0]))
  status={'status':'EMPIRICALLY_FITTED_WITH_HELDOUT_PARTICIPANTS_AND_IMAGES','participants':len(people),'train_responses':len(train),'test_responses':len(test),'heldout_participants':len(testp),'heldout_images':len(testi),'heldout_brier_score':float(np.mean((pred-yt)**2)),'model':'regularized logistic regression of blind image features','warning':'Empirical predictive calibration, not proof of human equivalence or optical authentication'}
  (out/'human_data_audit.json').write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2));return
 # Calibration requires paired synthetic predictions and an explicitly held-out participant split.
 # Never fit behavioral parameters using responses from the held-out participants.
 status={'status':'EMPIRICAL_DESCRIPTIVES_ONLY','participants':len(people),'responses':len(valid),'calibration_model':'NOT_FITTED','reason':'A fitted model requires per-stimulus predictions linked to stimulus IDs, a prespecified participant split, and sufficient empirical observations. Do not mislabel descriptive rates as calibrated model.'}
 (out/'human_data_audit.json').write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2))
def template(a):
 out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 cols=['participant_id','stimulus_id','image_id','condition','decision_accept','recognition_label','confidence_0_100','decision_time_ms','unusable','consent_confirmed','session_id','viewing_distance_cm','presentation_order']
 savecsv(out/'HUMAN_RESPONSES_BLANK.csv',[],cols)
 (out/'HUMAN_STUDY_PROTOCOL.md').write_text('''# Prospective human-observer calibration protocol (not yet executed)\n\n**Do not recruit participants without applicable institutional ethics approval or documented exemption.**\n\n1. Define a human-only inspection task and independently authenticated reference custody. State exactly what the participant may see.\n2. Pre-register genuine vs wrong-partner decisions, separate fixed-mask alterations, viewing distance, print material, illumination, and physical alignment procedure.\n3. Recruit consenting observers; assign pseudonymous IDs. Store consent separately and never include personal identifiers in shared research CSVs.\n4. Randomize and counterbalance trial order, avoid training/test image leakage, record actual responses, response times, confidence and unusable presentations.\n5. Separate participant-level training, validation and held-out test cohorts *before* fitting perceptual parameters. Also hold out source images.\n6. Fit the observer model only to training humans; tune on validation; evaluate once on held-out humans and held-out images. Report calibration curves, Brier score, FAR, FRR, uncertainty and unusable rate.\n7. The calibration command in this package currently performs **descriptive empirical aggregation only**, not model fitting. No real human data are supplied.\n8. Label all digital/synthetic/physical/human results distinctly.\n''',encoding='utf-8')
 print('Created blank human response schema and prospective study protocol:',out)
def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
 b=sub.add_parser('benchmark');b.add_argument('--dataset',required=True);b.add_argument('--output',required=True);b.add_argument('--images',type=int,default=546);b.add_argument('--observers',type=int,default=100);b.add_argument('--repetitions',type=int,default=10);b.add_argument('--seed',type=int,default=20261116);b.add_argument('--alteration-fraction',type=float,default=.01)
 t=sub.add_parser('human-template');t.add_argument('--output',required=True)
 c=sub.add_parser('calibrate');c.add_argument('--responses',required=True);c.add_argument('--features',help='stimulus_features.csv from benchmark, required for fitting');c.add_argument('--output',required=True);c.add_argument('--seed',type=int,default=20261116);c.add_argument('--min-participants',type=int,default=12)
 a=p.parse_args();{'benchmark':run_benchmark,'human-template':template,'calibrate':calibrate}[a.command](a)
if __name__=='__main__':main()
