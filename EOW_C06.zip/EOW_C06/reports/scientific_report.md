# EOW_C06 — Challenge-Dependent Optical Integrity Diagnostic

**Verdict:** `NO_SECURITY_QUALIFIED_CONSTRUCTION` (finite toy-model evidence).

The challenge is drawn **after** adversarial commitment. The expected optical response is a **private trusted digital reference**, not a demonstrated unaided human verification step.

## Optimal integrity games

| Observer | Public fixed mask: vulnerable mask fraction | Fresh private: optimal mean | Fresh private: worst case | Fixed hidden: 2 online attempts |
|---|---:|---:|---:|---:|
| exact_or | 0.875000 | 0.500000 | 0.500000 | 0.750000 |
| black_count | 0.984375 | 0.500000 | 0.500000 | 0.750000 |

## Exact privacy across distinct views

| Observer | View | Maximum TV |
|---|---|---:|
| exact_or | public_A_only | 0.000000 |
| exact_or | A_and_mask_only | 0.000000 |
| exact_or | A_and_expected_only | 0.875000 |
| exact_or | A_mask_and_expected | 0.984375 |
| exact_or | A_and_B_compromised | 1.000000 |
| black_count | public_A_only | 0.000000 |
| black_count | A_and_mask_only | 0.000000 |
| black_count | A_and_expected_only | 0.000000 |
| black_count | A_mask_and_expected | 0.875000 |
| black_count | A_and_B_compromised | 1.000000 |

## Interpretation

- Public fixed challenge: a chosen replacement may exploit an observed OR collision.
- Fresh challenge: exact best precommit attack probability is **not** necessarily negligible.
- Repeated fresh challenges: the success probability increases with the number of allowed attempts.
- Reusing a hidden challenge: online oracle feedback enables coverage of more masks.
- Expected-response disclosure is assessed separately from the limited public-A-only secrecy game.
- A digital equality test is not proof of human-only optical authentication.
- One-bit perturbations are logical sensitivity checks, not fabrication/registration measurements.

## References

- [Naor and Shamir, Visual Cryptography](https://doi.org/10.1007/BFb0053419)
- [NIST FIPS 204](https://doi.org/10.6028/NIST.FIPS.204)
