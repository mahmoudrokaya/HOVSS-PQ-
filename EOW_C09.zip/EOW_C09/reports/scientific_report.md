# EOW_C09 — Adaptive Adversarial Engine

**Verdict:** NO_SECURITY_QUALIFIED_CONSTRUCTION.

## Exact finite-domain results

| Observer | One private attempt | Adaptive fixed mask | Fresh independent masks | Public mask vulnerable |
|---|---:|---:|---:|---:|
| exact_or | 0.500000 | 0.750000 | 0.750000 | 0.875000 |
| black_count | 0.500000 | 0.750000 | 0.750000 | 0.984375 |

## Security interpretation

Fixed-mask results use exact optimal adaptive policies after negative feedback.
Fresh-mask results assume independent uniformly random masks for every query.
Public-mask vulnerability permits selection after the mask is known.
The optical verifier is an ideal digital surrogate; no human perceptual claim follows.
C08 enrollment test results are imported, not re-executed. They cannot repair optical OR collisions.
No universal impossibility theorem is asserted.

## Sources

- [Naor and Shamir](https://doi.org/10.1007/BFb0053419)
- [NIST FIPS 204](https://doi.org/10.6028/NIST.FIPS.204)
