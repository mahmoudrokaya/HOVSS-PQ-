# EOW_C13 — Simulated minor source distortion reference

**SIMULATION ONLY. No physical print, overlay photograph, or human trial was performed.**

This package mirrors the input hierarchy within `samples/<relative/subfolder>/<ID>/` contains two A4
print PDFs, A/B previews, ideal overlay, binary secret, decoded secret, resized
color source, and comparison guide. `source_original_resized.png` additionally
preserves the pre-distortion baseline. `ideal_metrics.csv` and
`captures_TEMPLATE.json` are regenerated consistently.

Only the resized source color image is randomly perturbed, at no more than 5% of
pixel locations. The color adjustment per selected pixel is at most 12 levels
per channel. A/B shares, ideal overlay, reference, PDFs, and metrics are
**regenerated from the same perturbed image**, not corrupted independently.
A single image pixel may change without changing the binary secret; this is
reported separately. The 0% ideal reconstruction error is a mathematical
property of digital OR-VSS with perfect alignment, not measured robustness.

The original input folder is not modified. PDFs are for future real printing at
100% actual size. Captures are blank until real photographs are collected.

Reference: Naor and Shamir, Visual Cryptography, https://doi.org/10.1007/BFb0053419
