# EOW_C04 — Full-Share Witness: Falsification-Oriented Audit

## Scope

This is an exhaustive **toy-model simulation** of two-subpixel Naor–Shamir VSS,
a full-share witness and binary OR stacking. It is not a physical or human experiment.

A protected enrolled witness may still leak the secret if compromised or made public.

## Security interpretation

* A fixed reference does not by itself establish issuer authenticity.
* Exact optical equality is an ideal computational observer, not a demonstrated human capability.
* OR stacking is many-to-one; the report distinguishes underlying share/XOR changes from visibly reconstructed OR-content changes.
* An exact copy is accepted by all static comparators.
* Privacy views explicitly include the witness, since an enrolled artifact can leak information.
* Logical shift/dropout stress is not physically calibrated.

## Exhaustive results

| Witness | Observer | Accepted visible-content changes | Modified candidates |
|---|---|---:|---:|
| witness_A | exact_subpixels | 0 | 4032 |
| witness_A | per_pixel_black_count | 0 | 4032 |
| witness_not_A | exact_subpixels | 448 | 4032 |
| witness_not_A | per_pixel_black_count | 448 | 4032 |
| witness_B | exact_subpixels | 296 | 4032 |
| witness_B | per_pixel_black_count | 296 | 4032 |
| witness_not_B | exact_subpixels | 296 | 4032 |
| witness_not_B | per_pixel_black_count | 296 | 4032 |
| witness_all_clear | exact_subpixels | 0 | 4032 |
| witness_all_clear | per_pixel_black_count | 448 | 4032 |

## Public-witness leakage with B

| Witness | Maximum TV |
|---|---:|
| witness_A | 1.000 |
| witness_not_A | 1.000 |
| witness_B | 0.000 |
| witness_not_B | 0.000 |
| witness_all_clear | 0.000 |

## Decision

**NO_SECURITY_QUALIFIED_CONSTRUCTION.** Passing an idealized OR integrity test is insufficient to claim human-verifiable issuer authenticity or post-quantum optical security.

## References

- Naor and Shamir: https://doi.org/10.1007/BFb0053419
- NIST FIPS 204: https://doi.org/10.6028/NIST.FIPS.204
