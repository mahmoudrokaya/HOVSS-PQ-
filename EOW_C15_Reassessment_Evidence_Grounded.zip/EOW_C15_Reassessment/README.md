# C15 reassessment package

Read `C15_revised_scientific_report.md` first. `C15_reconciled_sample_metrics.csv` holds sample-level numbers, and `C15_revised_summary.json` holds the evidence verdict. `build.py` reproduces the files from the eight original uploaded ZIPs when those archives are in `/mnt/data`; adjust input discovery paths for local Windows use.
