import csv,io,json,zipfile,glob,statistics,pathlib,hashlib
root=pathlib.Path('/mnt/data/EOW_C15_Reassessment'); files={}
for name in ['Cross_Version_Audit_Package(1)','Ideal_Reference_REGENERATED_20261116(1)','Minor_Manual_v3(1)','Physical_Pilot_Automation_Package(1)','Three_Sample_Physical_Pilot(2)','v1_1(1)','Human_Verification(1)','Human_Verification_Study_Package(3)']:
 p=next(p for p in glob.glob('/mnt/data/EOW_C13*.zip')+glob.glob('/mnt/data/EOW_C14*.zip') if name in pathlib.Path(p).name)
 files[name]=p

def get(name,suffix):
 with zipfile.ZipFile(files[name]) as z:
  matches=[x for x in z.namelist() if x.endswith(suffix)]
  if len(matches)!=1:raise ValueError((name,suffix,matches))
  return z.read(matches[0]).decode('utf-8-sig')
def rows(name,suffix):return list(csv.DictReader(io.StringIO(get(name,suffix))))
cross=rows('Cross_Version_Audit_Package(1)','cross_version_metrics.csv'); minor=rows('Minor_Manual_v3(1)','ideal_metrics.csv'); ideal=rows('Ideal_Reference_REGENERATED_20261116(1)','ideal_metrics.csv'); man=json.loads(get('Human_Verification(1)','study_manifest.json'))
setup=rows('Human_Verification(1)','STAFF_PAIR_SETUP.csv'); resp=rows('Human_Verification(1)','PARTICIPANT_RESPONSES_BLINDED.csv');pilot=rows('Three_Sample_Physical_Pilot(2)','pilot_observations.csv')
assert len(cross)==len(minor)==len(ideal)==8 and len(setup)==len(resp)==288
print('setup columns',list(setup[0]));print('resp columns',list(resp[0]));print('pilot',list(pilot[0]))
from collections import Counter
print('conditions',Counter(x.get('condition') for x in setup))
print('cross sample sum',sum(int(x['binary_changes']) for x in cross));print('distort sum',sum(int(x['distorted_pixel_count']) for x in minor))
N=sum(int(r['source_pixel_count']) for r in minor); D=sum(int(r['distorted_pixel_count']) for r in minor); B=sum(int(r['binary_changes']) for r in cross)
meanA=statistics.mean(float(r['cross_original_A_modified_B_rate_vs_original']) for r in cross)
meanB=statistics.mean(float(r['cross_modified_A_original_B_rate_vs_original']) for r in cross)
from collections import defaultdict
by_id={r['source_relative_path'].split('/')[-2]:r for r in minor}
with (root/'C15_reconciled_sample_metrics.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['sample','source_pixels','modified_source_pixels','source_modified_fraction','binary_changed_pixels','binary_change_fraction','original_ideal_errors','modified_ideal_errors','cross_A0_B1_error_fraction','cross_A1_B0_error_fraction','same_binary_secret'])
 for r in cross:
  m=by_id[r['sample']];w.writerow([r['sample'],m['source_pixel_count'],m['distorted_pixel_count'],m['distortion_fraction'],r['binary_changes'],r['binary_change_fraction'],r['original_ideal_error'],r['modified_ideal_error'],r['cross_original_A_modified_B_rate_vs_original'],r['cross_modified_A_original_B_rate_vs_original'],str(int(r['binary_changes'])==0)])
status={
 'status':'REASSESSED_FROM_UPLOADED_ARCHIVES', 'security_qualified':False,'prototype_selected_for_future_testing':'C13 OR-VSS printable shares (feasibility only)','secure_deployment_selection':None,
 'sample_count':8,'binary_pixels_total':N,'modified_source_pixels_total':D,'source_change_fraction':D/N,'binary_secret_changed_pixels_total':B,'binary_secret_change_fraction':B/N,'samples_binary_unchanged':sum(int(r['binary_changes'])==0 for r in cross),
 'original_ideal_reconstruction_errors':sum(int(r['original_ideal_error']) for r in cross),'modified_ideal_reconstruction_errors':sum(int(r['modified_ideal_error']) for r in cross),
 'cross_A0_B1_mean_error_fraction':meanA,'cross_A1_B0_mean_error_fraction':meanB,'human_study_planned_trials':len(setup),'human_observations':0,'physical_captures':0,'c13_v1_1_print_pairs':10,'pilot_print_pairs':3,
 'critical_caveats':['Source pixel perturbations are bounded by modified pixel locations, not 5% perceptual distortion.','Cross-version error is confounded by independent random share generation; not tamper-detection evidence.','Digital reference comparison is not human-only integrity verification.','Human study randomized assignments are not participant observations.','No physical printing or human trials demonstrated.','C01-C12 underlying raw evidence was not supplied in this upload set; do not re-certify earlier reported performance.']}
(root/'C15_revised_summary.json').write_text(json.dumps(status,indent=2)+'\n')
report=f'''# EOW_C15 — Evidence-grounded final reassessment

**Evidence scope:** Eight user-uploaded C13–C14 ZIP archives, inspected directly. This is a reassessment of supplied artifacts, not a claim of new physical or human experiments. Earlier C01–C12 raw datasets were **not** supplied and cannot be independently re-audited from this package.

## Revised research decision

- **Engineering prototype:** retain C13 printable, two-share OR-based visual secret sharing for future physical feasibility tests.
- **Integrity/security-qualified candidate:** **none**. The archive set does not support a tamper-detection, issuer-authenticity, human-only integrity, or quantum-resistance claim for the printed construction.
- **Study stage:** digital feasibility demonstrated in the tested sample set; physical feasibility and human outcomes unmeasured.

## What the actual files establish

| Evidence | Direct result | Boundary of inference |
|---|---|---|
| C13 v1.1 | 10 print pairs generated; 0 failures | 0 real captures; PDF generation is not physical validation |
| C13 ideal reference | 8 image pairs; 16 printable PDFs; 0 reconstruction errors across {N:,} binary pixel positions | Ideal deterministic digital reconstruction, not optical performance |
| Minor source perturbation | {D:,}/{N:,} source pixel positions modified ({100*D/N:.3f}% pooled), with each image below 5%; {B} binary-secret pixels changed ({100*B/N:.4f}% pooled) | Pixel-count perturbation is not perceptual robustness; newly generated shares reconstruct their newly generated secret |
| Binary invariance | 2/8 samples (6046, 8068) have no binary-secret changes | Some source changes are erased by the binary thresholding/quantization step |
| Cross-version | Mean A₀+B₁ error {100*meanA:.3f}%; mean A₁+B₀ error {100*meanB:.3f}% | Independently regenerated masks confound image changes and share incompatibility |
| Three-sample physical pilot | 3 prepared print pairs and blank QC records | No print calibration, physical photograph, or overlay judgment recorded |
| C14 prospective study | 12 participants × 24 trials = 288 assignments; 96 per condition | 0 completed responses; no FAR, FRR, recognition, or time measurements |

## Key deductions and research significance

**Finding A — Information loss before share generation.** Across all eight images, the source perturbation affected {D} pixel positions but only {B} binary-secret pixels. The ratio {B}/{D} = {100*B/D:.2f}% is a descriptive conversion rate for these particular perturbations and images, **not** a general sensitivity or detection probability. For 6046 and 8068, the modified color images produce unchanged binary secrets. Consequently, any verifier that only observes the binary reconstructed secret cannot distinguish those source variants using that representation alone. This is a representational limitation, not a claim that every conceivable authentication design must fail.

**Finding B — Randomization incompatibility masquerades as change detection.** Cross-version reconstruction error is ~49%, but each version used independently randomized shares. In the two unchanged-binary-secret cases, mixed shares still differ substantially. Thus cross-version error is not evidence of integrity sensitivity. A controlled experiment must fix A₀ and the random encoding, compute B₁ using the same mask, and then compare overlays and explicit decision rules.

**Finding C — Exact ideal reconstruction is not a security metric.** Both original and modified matching share pairs have zero ideal digital reconstruction errors. That follows from their construction and ideal alignment; it does not establish printing tolerance, human recognizability, or resistance to deliberate tampering.

**Finding D — Study design is not study evidence.** The C14 design is balanced and usable as a prospective protocol. The response sheet and physical QC records are blank; genuine participant accuracy, FAR/FRR and confidence intervals are undefined. Even when conducted, wrong-partner and misregistration conditions should be reported separately from adaptive forgery tests.

## Candidate decision matrix

| Candidate | Digital reconstruction | Human physical evidence | Integrity evidence | Decision |
|---|---|---|---|---|
| C13 ideal OR-VSS printable prototype | Supported on 8 tested images | None | Not demonstrated | **Retain for optical feasibility only** |
| Independently regenerated C13 distorted shares | Supported for each matching pair | None | Cross-version results confounded | **Reject as evidence of tamper detection** |
| C14 planned human-observer protocol | 288 assignments prepared | None | No observed human decisions | **Await ethics and real observations** |
| Security-qualified, unaided human integrity verifier | Not established | None | Not established | **No selection** |

## Priority follow-up experiments

1. **Fixed-mask controlled perturbation:** preserve original Share A and its random mask, modify only Share B consistently with the new secret. Include zero-binary-change controls and known positive modifications. Measure raw binary reconstruction, optical overlay, and detection decisions separately.
2. **Physical calibration:** print at 100%, verify 10-mm bars, log media and printer, quantify registration in millimeters, and capture original smartphone photos with unedited files.
3. **Human study after ethics clearance:** preregister decision rule and image-recognition rubric; collect blinded real observations; compute condition-specific errors with participant-clustered uncertainty. Do not treat 288 trials as 288 independent participants.
4. **Adversarial qualification:** separately evaluate unauthorized modification, share substitution, replay, and adaptive attackers against a defined threat model. The earlier C01–C12 raw evidence must be supplied to validate any consolidated historical claim.

## Claim language appropriate for a manuscript

> The experiments demonstrated exact ideal digital reconstruction for eight printable OR-VSS share pairs and showed that small color-image perturbations were often suppressed by binary preprocessing. Independently regenerated share pairs exhibited substantial cross-version incompatibility, but this effect cannot be attributed to tampering because the share randomization was not controlled. Physical reconstruction and human verification remain untested, and no security-qualified construction was identified.

## Provenance and limitations

All numbers are computed from the uploaded CSVs and JSONs. Sample metrics are preserved in `C15_reconciled_sample_metrics.csv`; `C15_revised_summary.json` provides machine-readable conclusions. A script reproduces the summary from the eight original archives. No simulated result is labeled a physical observation. Source reference for classical visual cryptography: Naor and Shamir (1994), https://doi.org/10.1007/BFb0053419 .
'''
(root/'C15_revised_scientific_report.md').write_text(report)
(root/'README.md').write_text('# C15 reassessment package\n\nRead `C15_revised_scientific_report.md` first. `C15_reconciled_sample_metrics.csv` holds sample-level numbers, and `C15_revised_summary.json` holds the evidence verdict. `build.py` reproduces the files from the eight original uploaded ZIPs when those archives are in `/mnt/data`; adjust input discovery paths for local Windows use.\n')
print(json.dumps(status,indent=2))
