# EOW_C15 — Evidence-grounded final reassessment

**Evidence scope:** Eight user-uploaded C13–C14 ZIP archives, inspected directly. This is a reassessment of supplied artifacts, not a claim of new physical or human experiments. Earlier C01–C12 raw datasets were **not** supplied and cannot be independently re-audited from this package.

## Revised research decision

- **Engineering prototype:** retain C13 printable, two-share OR-based visual secret sharing for future physical feasibility tests.
- **Integrity/security-qualified candidate:** **none**. The archive set does not support a tamper-detection, issuer-authenticity, human-only integrity, or quantum-resistance claim for the printed construction.
- **Study stage:** digital feasibility demonstrated in the tested sample set; physical feasibility and human outcomes unmeasured.

## What the actual files establish

| Evidence | Direct result | Boundary of inference |
|---|---|---|
| C13 v1.1 | 10 print pairs generated; 0 failures | 0 real captures; PDF generation is not physical validation |
| C13 ideal reference | 8 image pairs; 16 printable PDFs; 0 reconstruction errors across 22,016 binary pixel positions | Ideal deterministic digital reconstruction, not optical performance |
| Minor source perturbation | 725/22,016 source pixel positions modified (3.293% pooled), with each image below 5%; 15 binary-secret pixels changed (0.0681% pooled) | Pixel-count perturbation is not perceptual robustness; newly generated shares reconstruct their newly generated secret |
| Binary invariance | 2/8 samples (6046, 8068) have no binary-secret changes | Some source changes are erased by the binary thresholding/quantization step |
| Cross-version | Mean A₀+B₁ error 49.355%; mean A₁+B₀ error 49.341% | Independently regenerated masks confound image changes and share incompatibility |
| Three-sample physical pilot | 3 prepared print pairs and blank QC records | No print calibration, physical photograph, or overlay judgment recorded |
| C14 prospective study | 12 participants × 24 trials = 288 assignments; 96 per condition | 0 completed responses; no FAR, FRR, recognition, or time measurements |

## Key deductions and research significance

**Finding A — Information loss before share generation.** Across all eight images, the source perturbation affected 725 pixel positions but only 15 binary-secret pixels. The ratio 15/725 = 2.07% is a descriptive conversion rate for these particular perturbations and images, **not** a general sensitivity or detection probability. For 6046 and 8068, the modified color images produce unchanged binary secrets. Consequently, any verifier that only observes the binary reconstructed secret cannot distinguish those source variants using that representation alone. This is a representational limitation, not a claim that every conceivable authentication design must fail.

**Finding B — Randomization incompatibility masquerades as change detection.** Cross-version reconstruction error is ~49%, but each version used independently randomized shares. In the two unchanged-binary-secret cases, mixed shares still differ substantially. Thus cross-version error is not evidence of integrity sensitivity. A controlled experiment must fix A₀ and the random encoding, compute B₁ using the same mask, and then compare overlays and explicit decision rules.

**Finding C — Exact ideal reconstruction is not a security metric.** Both original and modified matching share pairs have zero ideal digital reconstruction errors. That follows from their construction and ideal alignment; it does not establish printing tolerance, human recognizability, or resistance to deliberate tampering.

**Finding D — Study design is not study evidence.** The C14 design is balanced and usable as a prospective protocol. The response sheet and physical QC records are blank; genuine participant accuracy, FAR/FRR and confidence intervals are undefined. Even when conducted, wrong-partner and misregistration conditions should be reported separately from adaptive forgery tests.

## Candidate decision matrix

| Candidate | Digital reconstruction | Human physical evidence | Integrity evidence | Decision |
|---|---|---|---|---|
| C13 ideal OR-VSS printable prototype | Supported on 8 tested images | None | Not demonstrated | **Retain for optical feasibility only** |
| Independently regenerated C13 distorted shares | Supported for each matching pair | None | Cross-version results confounded | **Reject as evidence of tamper detection** |
| C14 planned human-observer protocol | 288 assignments prepared | None | No observed human decisions | **Await ethics and real observations** |
| Security-qualified, unaided human integrity verifier | Not established | None | Not established | **No selection** |

## Priority follow-up experiments

1. **Fixed-mask controlled perturbation:** preserve original Share A and its random mask, modify only Share B consistently with the new secret. Include zero-binary-change controls and known positive modifications. Measure raw binary reconstruction, optical overlay, and detection decisions separately.
2. **Physical calibration:** print at 100%, verify 10-mm bars, log media and printer, quantify registration in millimeters, and capture original smartphone photos with unedited files.
3. **Human study after ethics clearance:** preregister decision rule and image-recognition rubric; collect blinded real observations; compute condition-specific errors with participant-clustered uncertainty. Do not treat 288 trials as 288 independent participants.
4. **Adversarial qualification:** separately evaluate unauthorized modification, share substitution, replay, and adaptive attackers against a defined threat model. The earlier C01–C12 raw evidence must be supplied to validate any consolidated historical claim.

## Claim language appropriate for a manuscript

> The experiments demonstrated exact ideal digital reconstruction for eight printable OR-VSS share pairs and showed that small color-image perturbations were often suppressed by binary preprocessing. Independently regenerated share pairs exhibited substantial cross-version incompatibility, but this effect cannot be attributed to tampering because the share randomization was not controlled. Physical reconstruction and human verification remain untested, and no security-qualified construction was identified.

## Provenance and limitations

All numbers are computed from the uploaded CSVs and JSONs. Sample metrics are preserved in `C15_reconciled_sample_metrics.csv`; `C15_revised_summary.json` provides machine-readable conclusions. A script reproduces the summary from the eight original archives. No simulated result is labeled a physical observation. Source reference for classical visual cryptography: Naor and Shamir (1994), https://doi.org/10.1007/BFb0053419 .
