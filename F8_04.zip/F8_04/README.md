F8_04 Candidate A: lattice-style PUBLIC anchor audit.

This is a falsification-oriented toy candidate, NOT an ML-DSA implementation or proven issuer authentication.

Outputs are in reports/ and mathematical_validation/.
