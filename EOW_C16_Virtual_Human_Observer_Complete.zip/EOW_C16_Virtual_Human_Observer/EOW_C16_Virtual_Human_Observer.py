#!/usr/bin/env python3
"""EOW C16: explicitly UNCALIBRATED synthetic observer simulation. Python 3.10+."""
import argparse,csv,hashlib,io,json,math,zipfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter
IDS=('2018','3063','5096','6046','8068','10081','14085','14092')
CONDITIONS=(
 ('original_ideal','original','valid'),('original_shift_1','original','invalid_alignment'),
 ('original_shift_3','original','invalid_alignment'),('original_rotate_1deg','original','invalid_alignment'),
 ('original_wrong_partner','original','invalid_partner'),('fixed_modified_ideal','fixed_modified','altered'),
 ('fixed_modified_shift_1','fixed_modified','altered_alignment'),
 ('fixed_modified_blur','fixed_modified','altered_optical'),
 ('fixed_modified_ink_spread','fixed_modified','altered_optical'))

def get(z,n):return np.asarray(Image.open(io.BytesIO(z.read(n))).convert('L'))
def entries(z):
 d={}
 for n in z.namelist():
  if n.endswith('/reference_binary_secret.png'):
   sid=next((v for v in n.split('/') if v in IDS),None)
   if sid:d[sid]=n.rsplit('/',1)[0]+'/'
 return d

def extract(z,n,w,h):
 img=get(z,n);H,W=img.shape;choices=[]
 for cell in range(2,33):
  dx=W-2*w*cell;dy=H-h*cell
  if dx<0 or dy<0 or dx%2 or dy%2:continue
  mx=dx//2;my=dy//2
  a=img[my+cell//2:my+h*cell:cell,mx+cell//2:mx+2*w*cell:cell]
  if a.shape==(h,2*w):
   b=a<128;score=np.mean(b.reshape(h,w,2).sum(axis=2)==1)
   choices.append((score,cell,b))
 if not choices:raise ValueError('Preview share grid not found: '+n)
 score,cell,b=max(choices,key=lambda v:(v[0],v[1]))
 if score<.999:raise ValueError('Ambiguous share preview: '+n)
 return b

def decode(a,b):return np.logical_and(a|b,True).reshape(a.shape[0],a.shape[1]//2,2).all(2)
def fixed_b(a,secret):
 # OR 2-subpixel VSS: secret black -> B=complement(A); white -> B=A.
 return np.where(np.repeat(secret,2,axis=1),~a,a)
def shift(a,dx,dy):
 out=np.zeros_like(a);h,w=a.shape
 sx0=max(0,-dx);sx1=min(w,w-dx);sy0=max(0,-dy);sy1=min(h,h-dy)
 if sx1>sx0 and sy1>sy0:out[sy0+dy:sy1+dy,sx0+dx:sx1+dx]=a[sy0:sy1,sx0:sx1]
 return out

def optical(a,b,cond):
 # Each subpixel represented at 3x3 digital display pixels. Not a physical calibration.
 A=np.repeat(np.repeat(a.astype('uint8')*255,3,0),3,1)
 B=np.repeat(np.repeat(b.astype('uint8')*255,3,0),3,1)
 if cond.endswith('shift_1'):B=shift(B,3,0)
 if cond.endswith('shift_3'):B=shift(B,9,0)
 if cond.endswith('rotate_1deg'):
  B=np.asarray(Image.fromarray(B).rotate(1,resample=Image.Resampling.BILINEAR,expand=False,fillcolor=0))
 overlay=np.maximum(A,B).astype('uint8')
 if cond.endswith('blur'):overlay=np.asarray(Image.fromarray(overlay).filter(ImageFilter.GaussianBlur(1.5)))
 if cond.endswith('ink_spread'):overlay=np.asarray(Image.fromarray(overlay).filter(ImageFilter.MaxFilter(3)))
 return overlay

def features(overlay,reference):
 # Black encoded as 255. The known reference is privileged information: an oracle-assisted
 # simulated recognizer, NOT evidence of unaided human recognition.
 ref=np.repeat(np.repeat(np.repeat(reference.astype('uint8')*255,2,axis=1),3,0),3,1)
 if overlay.shape!=ref.shape:raise ValueError('overlay shape mismatch')
 diff=np.abs(overlay.astype('float32')-ref.astype('float32'))/255
 agreement=1-float(np.mean(diff));contrast=float(np.std(overlay.astype('float32')/255)*2)
 return {'template_agreement':agreement,'contrast_proxy':min(1.,contrast),'mean_absolute_difference':1-agreement}

def sigmoid(x):return 1/(1+np.exp(-np.clip(x,-30,30)))
def read_inputs(original,modified):
 samples={};sha={}
 for label,p in [('original',original),('modified',modified)]:sha[label]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
 with zipfile.ZipFile(original) as za,zipfile.ZipFile(modified) as zb:
  ea,eb=entries(za),entries(zb)
  for sid in IDS:
   if sid not in ea or sid not in eb:raise ValueError('Missing sample '+sid)
   pa,pb=ea[sid],eb[sid];s0=get(za,pa+'reference_binary_secret.png')<128;s1=get(zb,pb+'reference_binary_secret.png')<128
   if s0.shape!=s1.shape:raise ValueError('secret shape mismatch '+sid)
   h,w=s0.shape;A=extract(za,pa+'share_A_preview.png',w,h);B=extract(za,pa+'share_B_preview.png',w,h)
   if not np.array_equal(decode(A,B),s0):raise ValueError('Original share reconstruction mismatch '+sid)
   Bfixed=fixed_b(A,s1)
   if not np.array_equal(decode(A,Bfixed),s1):raise ValueError('Fixed-mask modification failed '+sid)
   samples[sid]={'s0':s0,'s1':s1,'A':A,'B':B,'Bfixed':Bfixed,'changes':int(np.count_nonzero(s0^s1))}
 return samples,sha

def run(args):
 if args.observers<1 or args.repetitions<1:raise ValueError('observers/repetitions must be positive')
 out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 samples,sha=read_inputs(args.original,args.modified);rng=np.random.default_rng(args.seed)
 # These ranges are hypothetical priors, not fitted from human data.
 observers=[]
 for j in range(args.observers):
  observers.append({'observer_id':f'V{j+1:03d}', 'sensitivity':float(rng.lognormal(0,.22)),
   'criterion':float(rng.normal(.83,.035)), 'lapse':float(rng.uniform(.005,.055)),
   'noise_sd':float(rng.uniform(.025,.075)), 'fatigue_per_trial':float(rng.uniform(0,.00008)),
   'response_bias':float(rng.normal(0,.025))})
 stimuli=[];rows=[];visual_dir=out/'stimulus_previews';visual_dir.mkdir(exist_ok=True)
 for sid in IDS:
  d=samples[sid];s0=d['s0']
  next_sid=IDS[(IDS.index(sid)+1)%len(IDS)]
  for cond,version,truth in CONDITIONS:
   b=samples[next_sid]['B'] if cond=='original_wrong_partner' else (d['Bfixed'] if version=='fixed_modified' else d['B'])
   if b.shape!=d['A'].shape:
    # Wrong partner is reencoded using different random mask at same dimensions when needed.
    # To avoid a dimension mismatch, select a deterministic independent random-mask B with same geometry.
    local=np.random.default_rng(args.seed+int(sid)); mask=local.integers(0,2,size=d['A'].shape,dtype='uint8').astype(bool)
    b=np.where(np.repeat(s0,2,axis=1),mask,~mask)
   render=optical(d['A'],b,cond)
   f=features(render,s0)
   # Low-frequency perceptual cues are approximated; privileged template score is a model assumption.
   # Expected validity for 'altered' is invalid even if binary secret is unchanged: unavoidable indistinguishability.
   stimulus={'sample':sid,'condition':cond,'secret_version':version,'ground_truth':truth,
             'binary_secret_changes':d['changes'],**f}
   stimuli.append(stimulus)
   Image.fromarray(255-render).resize((render.shape[1]*2,render.shape[0]*2),Image.Resampling.NEAREST).save(visual_dir/f'{sid}_{cond}.png')
   for ob in observers:
    for rep in range(args.repetitions):
     trial=IDS.index(sid)*len(CONDITIONS)*args.repetitions+list(c[0] for c in CONDITIONS).index(cond)*args.repetitions+rep
     fatigue=ob['fatigue_per_trial']*trial
     evidence=(f['template_agreement']-.70)*ob['sensitivity']+.13*f['contrast_proxy']+ob['response_bias']-fatigue
     evidence+=float(rng.normal(0,ob['noise_sd']))
     prob=float(sigmoid((evidence-(ob['criterion']-.70))/.065))
     prob=ob['lapse']*.5+(1-ob['lapse'])*prob
     accepted=bool(rng.random()<prob)
     # Recognition is a separate hypothetical outcome, not inferred from accept/reject.
     p_rec=float(sigmoid((f['contrast_proxy']*.55+f['template_agreement']*.45-.58)/.10))
     p_rec=ob['lapse']*.125+(1-ob['lapse'])*p_rec
     recognized=bool(rng.random()<p_rec)
     conf=int(np.clip(1+round(4*abs(prob-.5)*2+float(rng.normal(0,.55))),1,5))
     latency=float(np.clip(rng.lognormal(math.log(2.0+2.5*(1-abs(2*prob-1))),.32),.25,30))
     rows.append({'evidence_type':'SYNTHETIC_UNCALIBRATED_SIMULATION','sample':sid,'condition':cond,
                  'ground_truth':truth,'observer_id':ob['observer_id'],'repetition':rep+1,
                  'accept':int(accepted),'recognize':int(recognized),'confidence_1_5':conf,
                  'response_time_seconds':round(latency,4),'model_accept_probability':round(prob,7)})
 fields=list(rows[0]);
 with (out/'synthetic_trials.csv').open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 with (out/'stimulus_metrics.csv').open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=list(stimuli[0]));w.writeheader();w.writerows(stimuli)
 with (out/'virtual_observer_parameters.csv').open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=list(observers[0]));w.writeheader();w.writerows(observers)
 summary=[]
 for cond,version,truth in CONDITIONS:
  subset=[r for r in rows if r['condition']==cond]
  summary.append({'condition':cond,'truth':truth,'trials':len(subset),
   'synthetic_accept_rate':round(float(np.mean([r['accept'] for r in subset])),6),
   'synthetic_recognition_rate':round(float(np.mean([r['recognize'] for r in subset])),6),
   'mean_model_accept_probability':round(float(np.mean([r['model_accept_probability'] for r in subset])),6),
   'mean_response_seconds':round(float(np.mean([r['response_time_seconds'] for r in subset])),4)})
 with (out/'condition_summary.csv').open('w',newline='',encoding='utf8') as f:
  w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
 manifest={'experiment':'EOW_C16','status':'SYNTHETIC_UNCALIBRATED_SIMULATION_ONLY','seed':args.seed,
  'observers':args.observers,'repetitions_per_observer_condition_image':args.repetitions,
  'conditions_per_image':len(CONDITIONS),'samples':list(IDS),'synthetic_trials':len(rows),
  'expected_trials':args.observers*args.repetitions*len(CONDITIONS)*len(IDS),
  'input_sha256':sha,'numpy_version':np.__version__,'pillow_version':Image.__version__,
  'physical_captures':0,'real_human_observations':0,'ethics_approval_inferred':False,
  'assumptions':{'sensitivity':'lognormal(meanlog=0,sdlog=0.22)','criterion':'normal(0.83,0.035)',
   'lapse':'uniform(0.005,0.055)','sensory_noise_sd':'uniform(0.025,0.075)',
   'fatigue_per_trial':'uniform(0,0.00008)','response_bias':'normal(0,0.025)',
   'optical_subpixel_display_scale':3,'translation_pixels_at_display_scale':[3,9],
   'rotation_degrees':1,'blur_radius':1.5,'ink_spread_max_filter':3,
   'recognition':'oracle-assisted template similarity and contrast, NOT validated human vision',
   'confidence_latency':'heuristic synthetic functions, NOT human-fitted'},
  'limitations':['No actual printing or physical optics measurements','No real human data or psychometric calibration',
   'Template access gives virtual observer privileged information','Source modifications erased by binarization cannot be distinguished by overlay-only observers',
   'Nine conditions are a fixed illustrative design, not exhaustive physical or attack coverage',
   'Synthetic accept/reject rates are not empirical FAR/FRR or security guarantees']}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
 report=['# EOW_C16 — Human-Inspired Virtual Observer Simulation','',
  '**Evidence classification: SYNTHETIC, UNCALIBRATED, DIGITAL-ONLY.**','',
  f'Executed {len(rows):,} synthetic decisions: {args.observers} virtual observers × {args.repetitions} repetitions × 9 conditions × 8 images.','',
  '## Construction and controls','',
  'Real original C13 share previews were decoded and checked against the supplied binary secrets. The original Share A was retained, and modified Share B was constructed with the SAME mask: B1=NOT(A0) for black secret pixels and B1=A0 for white secret pixels. Thus fixed-mask modification isolates the binary-secret change from random-mask replacement.','',
  'A wrong-partner condition uses a share from a different sample when dimensions match; otherwise a deterministic independently randomized wrong-mask surrogate is used. This is a proxy, not a physical pairing.','',
  '## Nine simulated optical conditions','',
  '| Condition | Ground truth | Synthetic acceptance | Synthetic recognition | Trials |','|---|---|---:|---:|---:|']
 for s in summary:report.append(f"| {s['condition']} | {s['truth']} | {s['synthetic_accept_rate']:.3f} | {s['synthetic_recognition_rate']:.3f} | {s['trials']} |")
 report+=['','## Scientific interpretation','',
  'The validity labels reflect experimental conditions, NOT measured human judgments. For fixed-mask alterations, an unchanged binary secret produces an identical ideal overlay; such source-level alterations are intrinsically invisible to an overlay-only observer.','',
  'A reference-template comparator is an **oracle-assisted** approximation of perceptual evidence and may overestimate detection. Model coefficients and population distributions are assumed, not estimated from participants. Therefore rates must never be called empirical human FAR, FRR, or security probabilities.','',
  'The results support reproducible computational stress testing and hypothesis generation, not independent physical validation, human validation, or cryptographic integrity.','',
  '## Assumptions, limitations, reproducibility','',
  'See manifest.json for numerical parameter assumptions, package hashes, dependencies, and limitations. Fixed RNG seed and full virtual-observer parameters are saved. The per-trial CSV is explicitly marked synthetic.','',
  '## Required empirical next steps','',
  '1. Measure actual printed calibration bars and photograph physical overlays. 2. Obtain ethics clearance and collect consented participant data. 3. Fit observer thresholds/lapse/noise using training participants and evaluate predictive performance on held-out participants. 4. Test security against adaptive attacks separately.','',
  '**C16 verdict: SIMULATION_COMPLETE; PHYSICAL_AND_HUMAN_VALIDATION_NOT_PERFORMED; NO_SECURITY_QUALIFIED_CONSTRUCTION.**','',
  'Foundation: Naor & Shamir (1994), Visual Cryptography, https://doi.org/10.1007/BFb0053419 .']
 (out/'EOW_C16_Evidence_Report.md').write_text('\n'.join(report)+'\n',encoding='utf8')
 print(json.dumps({'status':manifest['status'],'synthetic_trials':len(rows),'stimuli':len(stimuli),'output':str(out),'condition_summary':summary},indent=2))
 return 0

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--original',required=True,type=Path);p.add_argument('--modified',required=True,type=Path)
 p.add_argument('--output',required=True,type=Path);p.add_argument('--observers',type=int,default=100)
 p.add_argument('--repetitions',type=int,default=10);p.add_argument('--seed',type=int,default=20261116)
 return run(p.parse_args())
if __name__=='__main__':raise SystemExit(main())
