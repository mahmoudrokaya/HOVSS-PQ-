# EOW_C16 — Human-Inspired Virtual Observer Simulation

**Evidence classification: SYNTHETIC, UNCALIBRATED, DIGITAL-ONLY.**

Executed 72,000 synthetic decisions: 100 virtual observers × 10 repetitions × 9 conditions × 8 images.

## Construction and controls

Real original C13 share previews were decoded and checked against the supplied binary secrets. The original Share A was retained, and modified Share B was constructed with the SAME mask: B1=NOT(A0) for black secret pixels and B1=A0 for white secret pixels. Thus fixed-mask modification isolates the binary-secret change from random-mask replacement.

A wrong-partner condition uses a share from a different sample when dimensions match; otherwise a deterministic independently randomized wrong-mask surrogate is used. This is a proxy, not a physical pairing.

## Nine simulated optical conditions

| Condition | Ground truth | Synthetic acceptance | Synthetic recognition | Trials |
|---|---|---:|---:|---:|
| original_ideal | valid | 0.619 | 0.843 | 8000 |
| original_shift_1 | invalid_alignment | 0.052 | 0.671 | 8000 |
| original_shift_3 | invalid_alignment | 0.137 | 0.788 | 8000 |
| original_rotate_1deg | invalid_alignment | 0.229 | 0.738 | 8000 |
| original_wrong_partner | invalid_partner | 0.131 | 0.762 | 8000 |
| fixed_modified_ideal | altered | 0.614 | 0.839 | 8000 |
| fixed_modified_shift_1 | altered_alignment | 0.052 | 0.683 | 8000 |
| fixed_modified_blur | altered_optical | 0.455 | 0.543 | 8000 |
| fixed_modified_ink_spread | altered_optical | 0.240 | 0.389 | 8000 |

## Scientific interpretation

The validity labels reflect experimental conditions, NOT measured human judgments. For fixed-mask alterations, an unchanged binary secret produces an identical ideal overlay; such source-level alterations are intrinsically invisible to an overlay-only observer.

A reference-template comparator is an **oracle-assisted** approximation of perceptual evidence and may overestimate detection. Model coefficients and population distributions are assumed, not estimated from participants. Therefore rates must never be called empirical human FAR, FRR, or security probabilities.

The results support reproducible computational stress testing and hypothesis generation, not independent physical validation, human validation, or cryptographic integrity.

## Assumptions, limitations, reproducibility

See manifest.json for numerical parameter assumptions, package hashes, dependencies, and limitations. Fixed RNG seed and full virtual-observer parameters are saved. The per-trial CSV is explicitly marked synthetic.

## Required empirical next steps

1. Measure actual printed calibration bars and photograph physical overlays. 2. Obtain ethics clearance and collect consented participant data. 3. Fit observer thresholds/lapse/noise using training participants and evaluate predictive performance on held-out participants. 4. Test security against adaptive attacks separately.

**C16 verdict: SIMULATION_COMPLETE; PHYSICAL_AND_HUMAN_VALIDATION_NOT_PERFORMED; NO_SECURITY_QUALIFIED_CONSTRUCTION.**

Foundation: Naor & Shamir (1994), Visual Cryptography, https://doi.org/10.1007/BFb0053419 .
