# EOW_C16 — Reproducible virtual observer simulation

## Run (Python 3.10+)

Install dependencies: `python -m pip install numpy pillow`

Run from the directory containing the script:

```powershell
python EOW_C16_Virtual_Human_Observer.py `
  --original "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C13_Ideal_Reference_REGENERATED_20261116.zip" `
  --modified "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C13_Minor_Manual_v3.zip" `
  --output "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C16_Virtual_Human" `
  --observers 100 --repetitions 10 --seed 20261116
```

The example assumes the two input ZIP files are directly inside Results; change their paths if needed.

## Contents

- `EOW_C16_Virtual_Human_Observer.py`: executable source, input validation, and explicit simulation assumptions.
- `results/synthetic_trials.csv`: **72,000 synthetic observations** (not actual participants).
- `results/virtual_observer_parameters.csv`: 100 reproducible hypothetical observer profiles.
- `results/stimulus_metrics.csv`: 72 optical stimulus feature rows.
- `results/condition_summary.csv`: summary for all nine conditions.
- `results/stimulus_previews/`: 72 simulated optical renderings.
- `results/manifest.json`: source archive SHA-256 checksums, assumptions, dependencies, limitations.
- `results/EOW_C16_Evidence_Report.md`: scientific report.
- `run_log.json`: execution output.

## Interpretation and limitations

The model is an oracle-assisted template comparison with stochastic behavioral errors, **not** a validated emulation of unaided human vision. A wrong-partner condition may use a synthetic wrong-mask proxy when image sizes differ. The nine conditions are illustrative, not exhaustive. Optical distortions are defined in digital display pixels, not calibrated physical units. The acceptance probability is determined by assumed coefficients and must not be presented as empirical human FAR/FRR or evidence of cryptographic security.

There is no physical capture, human participant, or ethics approval in this simulation. Human testing still requires institutional ethics approval/exemption where applicable.

Scientific background: Naor & Shamir (1994), https://doi.org/10.1007/BFb0053419 .
