# EOW_C03 — Conditional Impossibility Bounds and Exact Counterexamples

**Scope:** Exact finite-domain XOR-sharing and binary-OR optical surrogate; n=2. No universal impossibility theorem is claimed.

## Findings

- Binary OR maps 16 ordered input pairs to 4 outputs, with 42 colliding unordered pairs of distinct ordered inputs.
- A fixed-first-share content-changing OR collision was found.
- Publicly recomputable enrollment can be rebound if an attacker can replace **all** untrusted enrollment information (P1).
- A separable authentication tag can be transplanted without authenticating mutable data (P2).
- Masked public witness (with independent hidden key) has maximum pairwise TV=0.000000 in the defined public view.
- Revealing the mask key together with the first share and masked second share yields TV=1.000000.
- A stateless deterministic verifier cannot distinguish an exact replay from the accepted original without extra assumptions.

## Interpretation

The OR collision counting theorem concerns the full ordered-pair domain, **not** necessarily a restricted valid-codeword subset. The secrecy identity concerns a digital XOR toy model, **not** a passive optical realization. The issuer-authenticity result assumes no protected trust anchor. These limitations are essential.

## Evidence

C02 source: LOADED. Self-tests: 11/11.

## Decision

`NO_SECURITY_QUALIFIED_CONSTRUCTION`. C04 should build a fully specified optical predicate and account for witness custody, secrecy, replay, and physical observability.

## References

- Naor and Shamir, Visual Cryptography: https://doi.org/10.1007/BFb0053419
- NIST FIPS 204, ML-DSA: https://doi.org/10.6028/NIST.FIPS.204
