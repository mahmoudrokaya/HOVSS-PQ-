#!/usr/bin/env python3
"""Compare original and minor-distorted C13 packages. All results digital only."""
import argparse,csv,io,json,zipfile,hashlib
from pathlib import Path
import numpy as np
from PIL import Image

def get(z,n):return np.array(Image.open(io.BytesIO(z.read(n))).convert('L'))
def entries(z):
    d={}
    for n in z.namelist():
        if n.endswith('/reference_binary_secret.png'):
            bits=n.split('/'); sid=next((v for v in bits if v in IDS),None)
            if sid:d[sid]=n.rsplit('/',1)[0]+'/'
    return d
IDS=('2018','3063','5096','6046','8068','10081','14085','14092')
def extract_share(z,prefix,w,h):
    img=get(z,prefix)
    H,W=img.shape
    possibilities=[]
    for cell in range(2,33):
        dx=W-2*w*cell;dy=H-h*cell
        if dx>=0 and dy>=0 and dx%2==0 and dy%2==0:
            # Centered payload with a nonzero margin; sample only cell interiors.
            mx=dx//2;my=dy//2
            samples=img[my+cell//2:my+h*cell:cell,mx+cell//2:mx+2*w*cell:cell]
            if samples.shape==(h,2*w):
                # VSS shares have exactly one black subpixel in each pair.
                binary=samples<128
                score=float(np.mean(binary.reshape(h,w,2).sum(2)==1))
                possibilities.append((score,cell,mx,my,binary))
    if not possibilities:raise ValueError('No preview grid found')
    score,cell,mx,my,bits=max(possibilities,key=lambda x:(x[0],x[1]))
    if score<.999:raise ValueError(f'Preview cannot be decoded unambiguously: {score:.3f}')
    return bits,{'cell_px':cell,'margin_x_px':mx,'margin_y_px':my}
def decode(a,b):return (a|b).reshape(a.shape[0],a.shape[1]//2,2).all(2)
def png(path,arr):Image.fromarray(np.where(arr,0,255).astype('uint8')).resize((arr.shape[1]*6,arr.shape[0]*6),Image.Resampling.NEAREST).save(path)
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--original',required=True,type=Path)
    ap.add_argument('--modified',required=True,type=Path)
    ap.add_argument('--output',required=True,type=Path)
    a=ap.parse_args();out=a.output;out.mkdir(parents=True,exist_ok=True)
    rows=[];fails=[]
    with zipfile.ZipFile(a.original) as za,zipfile.ZipFile(a.modified) as zb:
        orig=entries(za);mod=entries(zb)
        for sid in IDS:
            try:
                if sid not in orig or sid not in mod:raise ValueError('Missing sample in one archive')
                pa=orig[sid];pb=mod[sid]
                s0=get(za,pa+'reference_binary_secret.png')<128
                s1=get(zb,pb+'reference_binary_secret.png')<128
                if s0.shape!=s1.shape:raise ValueError('Binary secret shapes differ')
                h,w=s0.shape
                A0,ga=extract_share(za,pa+'share_A_preview.png',w,h)
                B0,_=extract_share(za,pa+'share_B_preview.png',w,h)
                A1,gb=extract_share(zb,pb+'share_A_preview.png',w,h)
                B1,_=extract_share(zb,pb+'share_B_preview.png',w,h)
                r00=decode(A0,B0);r11=decode(A1,B1)
                r01=decode(A0,B1);r10=decode(A1,B0)
                if not np.array_equal(r00,s0) or not np.array_equal(r11,s1):
                    raise ValueError('Extracted preview shares do not reproduce their references')
                folder=out/'samples'/sid;folder.mkdir(parents=True,exist_ok=True)
                for name,im in [('original_binary',s0),('modified_binary',s1),
                                ('binary_difference',s0^s1),('original_A_modified_B',r01),
                                ('modified_A_original_B',r10),('original_ideal',r00),('modified_ideal',r11)]:
                    png(folder/(name+'.png'),im)
                n=s0.size
                rows.append({'sample':sid,'pixels':n,'binary_changes':int(np.count_nonzero(s0^s1)),
                  'binary_change_fraction':float(np.mean(s0^s1)),
                  'original_ideal_error':int(np.count_nonzero(r00^s0)),
                  'modified_ideal_error':int(np.count_nonzero(r11^s1)),
                  'cross_original_A_modified_B_error_vs_original':int(np.count_nonzero(r01^s0)),
                  'cross_original_A_modified_B_rate_vs_original':float(np.mean(r01^s0)),
                  'cross_original_A_modified_B_rate_vs_modified':float(np.mean(r01^s1)),
                  'cross_modified_A_original_B_error_vs_original':int(np.count_nonzero(r10^s0)),
                  'cross_modified_A_original_B_rate_vs_original':float(np.mean(r10^s0)),
                  'cross_modified_A_original_B_rate_vs_modified':float(np.mean(r10^s1)),
                  'share_A_subpixel_difference_fraction':float(np.mean(A0^A1)),
                  'share_B_subpixel_difference_fraction':float(np.mean(B0^B1)),
                  'original_preview_grid':json.dumps(ga),'modified_preview_grid':json.dumps(gb),
                  'interpretation':'CROSS-PAIRING INDEPENDENTLY REGENERATED SHARES; NOT TAMPER DETECTION'})
            except Exception as e:fails.append({'sample':sid,'error':str(e)})
    with (out/'cross_version_metrics.csv').open('w',newline='') as f:
        if rows:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    with (out/'failures.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['sample','error']);w.writeheader();w.writerows(fails)
    summary={'samples_processed':len(rows),'samples_failed':len(fails),
       'mean_binary_change_fraction':float(np.mean([r['binary_change_fraction'] for r in rows])) if rows else None,
       'mean_cross_A0_B1_error_vs_original':float(np.mean([r['cross_original_A_modified_B_rate_vs_original'] for r in rows])) if rows else None,
       'mean_cross_A1_B0_error_vs_original':float(np.mean([r['cross_modified_A_original_B_rate_vs_original'] for r in rows])) if rows else None,
       'physical_captures':0,'security_qualified':False,
       'note':'Original and modified shares independently randomized; cross-pair mismatch does not prove integrity. Original and modified secrets may be identical.'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    (out/'README.md').write_text('# EOW C13 Cross-Version Audit\n\n'
      'Compare original versus minor-distorted binary secrets, and four share pairings: original A+B, modified A+B, original A+modified B, modified A+original B. '
      'All observations are simulated digital results, not physical or human data. '
      'Because shares are regenerated with independent random masks, cross-version incompatibility is expected even if the secret image is unchanged. '
      'This is NOT evidence of malicious tamper detection or optical integrity. '
      'See https://doi.org/10.1007/BFb0053419 .\n')
    print(json.dumps(summary,indent=2))
    return 0 if rows and not fails else 2
if __name__=='__main__':raise SystemExit(main())
