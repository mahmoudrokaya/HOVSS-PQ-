# EOW_C15 — Final Selection and Reporting

Python 3.10+; standard library only. No fabricated physical or participant data.

Run from any directory:

```powershell
python ".\EOW_C15_Final_Selection_and_Reporting.py" --evidence ".\evidence" --output ".\output"
```

Outputs: `C15_summary.json`, `C15_final_report.md`, `candidate_decisions.csv`, `C15_sample_metrics.csv`.

The included evidence is an immutable copy of provided experiment results. SHA-256 digests are emitted to the summary. The C12 architecture conclusions are historical summaries only; original C12 raw files were not included. No human FAR/FRR is computed without independently validated actual responses and ethics clearance. C13 cross-version results do not establish tamper detection.
