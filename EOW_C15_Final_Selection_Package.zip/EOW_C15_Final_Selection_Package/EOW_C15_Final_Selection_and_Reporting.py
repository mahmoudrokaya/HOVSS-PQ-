#!/usr/bin/env python3
"""EOW C15: evidence-gated final selection/reporting. Python 3.10+, stdlib only."""
import argparse,csv,json,statistics,hashlib
from pathlib import Path

def rows(p):
    with p.open('r',encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def num(v):
    try:return float(v)
    except (ValueError,TypeError):return None

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence',default=str(Path(__file__).resolve().parent/'evidence'))
    parser.add_argument('--output',default=str(Path(__file__).resolve().parent/'output'))
    a=parser.parse_args();e=Path(a.evidence);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    required=['cross_version_metrics.csv','participant_responses.csv','study_manifest.json','alignment_conditions.csv','ideal_metrics.csv','ethics_checklist.csv']
    absent=[n for n in required if not (e/n).is_file()]
    if absent:parser.error('Missing evidence: '+', '.join(absent))
    cross=rows(e/required[0]); resp=rows(e/required[1]);manifest=json.loads((e/required[2]).read_text(encoding='utf-8-sig'))
    align=rows(e/required[3]);ideal=rows(e/required[4]);ethics=rows(e/required[5]);
    if len({r.get('sample') for r in cross})!=len(cross):raise ValueError('Duplicate sample in cross-version metrics')
    if len({(r.get('participant_id'),r.get('trial_id')) for r in resp})!=len(resp):raise ValueError('Duplicate participant/trial rows')
    if len(resp)!=manifest.get('trials_planned'):raise ValueError('Response rows differ from manifest trial count')
    if len(ideal)!=len(cross):raise ValueError('Ideal/cross sample count mismatch')
    if {r['sample'] for r in ideal}!={r['sample'] for r in cross}:raise ValueError('Ideal/cross sample IDs mismatch')
    response_fields=['response_valid','recognized_image','confidence_1_5','time_seconds']
    completed=[r for r in resp if any((r.get(k) or '').strip() for k in response_fields)]
    partial=[r for r in completed if not (r.get('response_valid') or '').strip()]
    approval=[r for r in ethics if 'approval or formal exemption' in r.get('requirement','').lower()]
    approval_ok=bool(approval) and all(r.get('status','').strip().upper() in ('APPROVED','EXEMPT','COMPLETE','VERIFIED') and r.get('evidence_reference','').strip() for r in approval)
    physical=sum(int(num(r.get('physical_captures')) or 0) for r in ideal)
    fractions=[num(r['binary_change_fraction']) for r in cross]
    ab=[num(r['cross_original_A_modified_B_rate_vs_original']) for r in cross]
    ba=[num(r['cross_modified_A_original_B_rate_vs_original']) for r in cross]
    if any(v is None for v in fractions+ab+ba):raise ValueError('Missing/non-numeric cross-version metric')
    ideal_errors=[num(r.get('ideal_reconstruction_pixel_errors')) for r in ideal]
    if any(v is None for v in ideal_errors):raise ValueError('Missing ideal error metrics')
    # These are research-stage candidates; scores are not fabricated.
    candidates=[
      {'candidate':'Reference-99','evidence':'C12 historical summary','status':'NOT_SECURITY_QUALIFIED','reason':'Reported failure to jointly satisfy FAR and FRR limits under all seven conditions'},
      {'candidate':'Reference-Exact','evidence':'C12 historical summary','status':'NOT_SECURITY_QUALIFIED','reason':'Reported failure to jointly satisfy FAR and FRR limits under all seven conditions'},
      {'candidate':'Registration-Exact','evidence':'C12 historical summary','status':'NOT_SECURITY_QUALIFIED','reason':'Reported failure to jointly satisfy FAR and FRR limits under all seven conditions'},
      {'candidate':'Digital-Digest','evidence':'C12 historical summary','status':'NOT_SECURITY_QUALIFIED','reason':'Uses trusted digital comparison; does not establish unaided human optical integrity'},
      {'candidate':'C13 OR-VSS printable prototype','evidence':'C13/C14 attached evidence','status':'DIGITAL_FEASIBILITY_ONLY','reason':'Zero ideal digital reconstruction errors; no verified physical captures or human responses'}]
    summary={
      'experiment':'EOW_C15_Final_Selection_and_Reporting',
      'evidence_integrity':{n:sha(e/n) for n in required},
      'digital_samples':len(ideal),'ideal_reconstruction_errors_total':int(sum(ideal_errors)),
      'mean_binary_change_fraction':statistics.mean(fractions),
      'mean_cross_A0_B1_error_fraction':statistics.mean(ab),
      'mean_cross_A1_B0_error_fraction':statistics.mean(ba),
      'alignment_condition_rows':len(align),
      'planned_participants':manifest.get('participants_planned'),
      'planned_trials':manifest.get('trials_planned'),
      'response_rows':len(resp),'rows_with_any_response':len(completed),
      'partially_filled_response_rows':len(partial),
      'physical_captures_documented':physical,
      'ethics_clearance_documented':approval_ok,
      'human_metrics_computable':False,
      'security_qualified':False,
      'selected_for_further_physical_feasibility':'C13 OR-VSS printable prototype',
      'selected_for_security_deployment':None,
      'overall_verdict':'NO_SECURITY_QUALIFIED_CONSTRUCTION',
      'limitations':['Cross-version pairs were independently randomized; mismatch is not integrity detection',
        'No measured physical reconstruction evidence','No verified human participant outcomes',
        'C12 candidate outcomes are historical reported summaries, not reaudited raw evidence in this package']
    }
    if completed:
      summary['human_metrics_computable']=False
      summary['limitations'].append('Response entries detected: human data require separate ethics and trial-key validation before FAR/FRR calculation')
    (out/'C15_summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    with (out/'candidate_decisions.csv').open('w',encoding='utf-8',newline='') as f:
      w=csv.DictWriter(f,fieldnames=['candidate','evidence','status','reason']);w.writeheader();w.writerows(candidates)
    with (out/'C15_sample_metrics.csv').open('w',encoding='utf-8',newline='') as f:
      w=csv.writer(f);w.writerow(['sample','binary_change_fraction','cross_A0_B1_error_fraction','cross_A1_B0_error_fraction','ideal_reconstruction_errors'])
      ix={r['sample']:r for r in ideal}
      for r in cross:w.writerow([r['sample'],r['binary_change_fraction'],r['cross_original_A_modified_B_rate_vs_original'],r['cross_modified_A_original_B_rate_vs_original'],ix[r['sample']]['ideal_reconstruction_pixel_errors']])
    report=f'''# EOW_C15 — Final Selection and Reporting\n\n## Decision\n\n**Security-qualified construction: NONE.**\n\n**Prototype for further physical feasibility testing:** C13 printable OR-VSS, selected solely because its digital reconstruction and printable artifacts are available. This is **not** a security endorsement or proof of superiority.\n\n## Audited attached evidence\n\n- C13 ideal digital samples: **{len(ideal)}**; total ideal reconstruction pixel errors: **{int(sum(ideal_errors))}**.\n- Mean binary-secret change: **{100*statistics.mean(fractions):.4f}%**.\n- Independently regenerated cross-version A0+B1 error: **{100*statistics.mean(ab):.4f}%**; A1+B0: **{100*statistics.mean(ba):.4f}%**. These do not measure tamper detection.\n- C13/C14 alignment manifest: **{len(align)}** conditions, not measured physical outcomes.\n- C14 planned participants: **{manifest.get('participants_planned')}**; planned trials: **{manifest.get('trials_planned')}**; response rows containing observations: **{len(completed)}**.\n- Verified physical captures recorded in C13 ideal metrics: **{physical}**.\n- Ethics clearance documented in supplied checklist: **{'YES' if approval_ok else 'NO'}**.\n\n## C12 candidate screening (historical summaries only)\n\nThe four C12 variants (Reference-99, Reference-Exact, Registration-Exact, Digital-Digest) were previously reported not to meet both FAR ≤ 5% and FRR ≤ 5% in all seven conditions. Their underlying raw C12 results are **not** supplied here, so these are carried forward as prior-study conclusions, not independently revalidated C15 calculations.\n\n## Interpretation and decision boundaries\n\nExact ideal digital reconstruction does not demonstrate physical usability, human recognition, tamper detection, authentication, or post-quantum security. In particular, large cross-version differences caused by independent random masks are a confounder. A cryptographic enrollment signature can protect digital records without proving that unaided optical overlay reveals tampering.\n\n## Evidence required before stronger claims\n\n1. Perform a documented physical print-and-overlay pilot with calibration measurements, photos, and failures.\n2. Obtain institutional ethics approval or exemption, then collect genuine participant responses under a blinded protocol.\n3. Independently evaluate aligned, wrong-partner, and misregistered conditions; report FAR/FRR with uncertainty and participant-level dependence.\n4. Perform a fixed-mask controlled alteration test, retaining A0 while recomputing B1, to isolate content change from independent randomization.\n5. Reaudit original C12 raw metrics and prespecified security thresholds before any final architecture recommendation.\n\n**Final research verdict: `NO_SECURITY_QUALIFIED_CONSTRUCTION`.**\n'''
    (out/'C15_final_report.md').write_text(report,encoding='utf-8')
    print(json.dumps({'status':'COMPLETE_WITH_EVIDENCE_GAPS','output':str(out),'samples':len(ideal),'human_responses':len(completed),'security_qualified':False},indent=2))
if __name__=='__main__':main()
