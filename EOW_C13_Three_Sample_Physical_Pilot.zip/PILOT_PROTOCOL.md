# EOW_C13 — Three-Sample Physical Pilot (v1.1)

## Purpose
Test real-world print scale, optical overlay reconstruction, and capture fidelity for samples **0001, 0002, 0004**. This is **not** a test of cryptographic integrity or unaided human authentication.

## Materials
- Six PDF pages (A and B for each of three samples)
- Printer capable of transparent-film printing; compatible clear sheets
- Ruler (preferably calipers), flat transparent support, tape/clips, diffuse even lighting, camera or smartphone
- Optional: tripod/stand and backlight

## Print procedure
1. Print each A/B PDF on clear film using **100% / Actual Size**. Disable Fit to Page, Shrink, and scaling.
2. Verify the **10 mm calibration bar** with a ruler and record its measured length; record the printer, media and settings.
3. Print A and B in the same orientation. Do not mirror either page.
4. Align the four **cross-shaped registration marker centers**. Keep sheets flat and parallel, and avoid parallax.
5. Photograph the actual A+B overlay approximately perpendicular to the sheet, with even lighting. Include all four crosses in the photograph.
6. Capture a second image after removing and realigning B to estimate repeatability (recommended).
7. Record physical observations without looking at the ideal reference first, if assessing visibility.

## Capture manifest
The bundled `captures.json` has only the three selected records and **relative preview paths**. Place real photographs in `captures/` and set each record's `capture_path` to a relative filename, e.g. `captures/0001_overlay.jpg`. Set `corners_px` to the manually measured image-pixel coordinates of the **four cross centers** in order `[top-left, top-right, bottom-right, bottom-left]`. The evaluator will warp the photo into the reference preview coordinate system.

**Important:** The current C13 evaluator resolves `capture_path` relative to the manifest directory, but its `ideal_overlay_png` may be resolved relative to the process working directory. To avoid path problems, use the supplied pilot evaluation wrapper or convert `ideal_overlay_png` entries to absolute paths before running the original evaluator.

## Measurements
- Printed calibration bar (mm), percent deviation from 10 mm
- Visual reconstruction observed? (yes / partial / no)
- Alignment difficulty, lighting, visible artifacts
- Pixel mismatch at thresholds 96, 128 and 160 after four-point registration
- Mean white-minus-black intensity contrast
- Differences between independent realignments

## Interpretation
A good physical overlay supports optical **reconstruction feasibility** only. The tested shares do not provide a security-qualified integrity witness. Do not classify electronic reference matching as human-only verification.

## Reference
Naor & Shamir, Visual Cryptography: https://doi.org/10.1007/BFb0053419
