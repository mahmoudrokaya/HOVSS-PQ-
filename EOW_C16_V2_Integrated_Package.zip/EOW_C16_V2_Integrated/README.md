# EOW_C16 v2 — Integrated Experiments A–F

This package implements six linked **digital-only** experiments using the **actual outputs of earlier C13 experiments** and optionally consumes C13 cross-version, C14, C16 v1 and C12 archives for provenance and comparisons. It does not claim physical printing, genuine human data, semantic recognition, cryptographic authentication, or validated human FAR/FRR.

## Requirements

Python 3.10+; `python -m pip install numpy pillow`.

## Input mapping

| Earlier output | Argument | Consumed by | Required? |
|---|---|---|---|
| C13 original ideal ZIP | `--original` | A exact reconstruction, B observer, C optical, D behavioral, E fixed-mask, F sensitivity | Yes |
| C13 minor distortion ZIP | `--modified` | A changed secrets, C fixed-mask stimulus, E attack severity | Yes |
| C13 cross-version audit ZIP | `--cross` | G historical provenance and comparison | No |
| C14 human study ZIP | `--c14` | G trial-plan provenance; no synthetic responses treated as humans | No |
| C16 v1 results ZIP | `--c16-v1` | G prior model comparison | No |
| C12 candidate results ZIP | `--c12` | G candidate evidence inventory, not an authenticated security gate | No |

Optional historical inputs do **not** influence the blind observer's decisions, because doing so could leak labels, templates, or condition outcomes.

## Windows PowerShell (run in your Code directory)

```powershell
python .\EOW_C16_V2_Integrated.py `
  --original "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C13_Ideal_Reference_REGENERATED_20261116.zip" `
  --modified "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C13_Minor_Manual_v3.zip" `
  --output "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C16_V2" `
  --observers 100 --repetitions 10 --seed 20261116
```

Add `--cross`, `--c14`, `--c16-v1`, and `--c12` with full ZIP paths if available.

## Six experiments and outputs

A: `A_exact_reconstruction_audit.csv` — checks original and fixed-mask modified reconstruction against C13 binary secrets. Fails fast if invalid.

B: `B_blind_vs_oracle_features.csv` — blind-only multiscale image features and a separately labeled privileged oracle diagnostic. The oracle score is **not used** by the simulated observer.

C: `C_optical_stimulus_metrics.csv`, `C_optical_previews/` — nine optical conditions on eight images, uncalibrated display-pixel units.

D: `D_observer_parameters.csv`, `D_synthetic_trials.csv` — 100 virtual observers × 10 repetitions × 9 conditions × 8 images = 72,000 **synthetic** decisions, confidence and latency.

E: `E_attack_severity.csv` — fixed-mask modified secrets, severity, and observational-equivalence controls. Fixed-mask alteration is **not automatically attacker-feasible**.

F: `F_cluster_uncertainty.csv`, `F_parameter_sensitivity.csv`, `F_manifest.json`, `F_complete_evidence_report.md` — simulation-only uncertainty and explicit assumptions.

G: `G_prior_experiment_evidence.json` — optional earlier-archive evidence inventory and input SHA-256.

## Important boundaries

1. The blind model is a transparent image-statistics proxy, **not a trained vision model** and not a validated human psychophysical model. It cannot provide defensible semantic recognition or calibrated human FAR/FRR.
2. No human recruitment, physical experiment, or ethics approval is inferred from these files.
3. A fixed-mask modified share is a *controlled content perturbation* and may not represent a feasible attack under the manuscript threat model.
4. This is an **eight-image pilot**, not the paper's 539-real/7-synthetic full benchmark.
5. The paper's issuer-to-optical authentication mechanism is not implemented or proven. The security verdict remains `NO_SECURITY_QUALIFIED_CONSTRUCTION`.

## Reproducibility checks

`python -m py_compile EOW_C16_V2_Integrated.py` and verify `F_manifest.json`, output row counts, exact-reconstruction audit, and archive SHA-256 hashes. The example results in this package were executed on the two specified C13 archives, with optional C13-cross/C14/C16-v1 provenance.

Scientific references: Naor and Shamir, Visual Cryptography (https://doi.org/10.1007/BFb0053419); NIST FIPS 204 (https://doi.org/10.6028/NIST.FIPS.204).
