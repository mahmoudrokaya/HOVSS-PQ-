# EOW_C16 v2 — Integrated experiments A–F

**Evidence classification: UNCALIBRATED DIGITAL SIMULATION; NOT PHYSICAL OR HUMAN VALIDATION.**

Inputs: 8 matched C13 images, 9 conditions, 100 synthetic observers, 10 repetitions; **72,000 synthetic decisions**.

## A. Reconstruction correctness
Original and fixed-mask reconstructions pass: 8/8. Changed binary secrets: 15 pixels; unchanged binary secrets: 2 images.

## B. Protocol-constrained observer
The stochastic decision model uses ONLY blind image-derived features; an oracle similarity comparator is stored separately and never passed into the decision model. The blind features are NOT validated semantic object recognition or measured human perception.

## C. Optical model
Digital OR overlay with subpixel translation, rotation, blur and dilation. Scale, transmission, lighting, and film physics are NOT calibrated to real hardware. Nonmonotonic shift responses may arise from two-subpixel periodic geometry.

## D. Behavioral variability
100 observer parameter vectors (default) and all synthetic decisions saved. Priors, confidence, and response time are assumptions, not human-fitted distributions.

## E. Adversarial severity
Fixed-mask B1 uses original A and modified binary secret. This is a controlled content perturbation, NOT necessarily an attacker-feasible forgery. Source modifications erased by binarization yield indistinguishable observations. Wrong-partner controls are not proof of cryptographic authentication.

## F. Sensitivity and uncertainty
Observer/image clustered bootstrap describes variability inside the synthetic model, NOT empirical confidence in human FAR/FRR. Parameter sweep demonstrates model dependence. No physical/human gate is passed.

## Synthetic acceptance summary
|Condition|Rate|Model-only cluster interval|
|---|---:|---:|
|original_ideal|0.5829|[0.4497, 0.6768]|
|original_shift_1|0.5649|[0.5148, 0.6111]|
|original_shift_3|0.5506|[0.5029, 0.5963]|
|original_rotate_1deg|0.4871|[0.4334, 0.5451]|
|original_wrong_partner|0.5969|[0.5464, 0.6389]|
|fixed_modified_ideal|0.5846|[0.4778, 0.6765]|
|fixed_modified_shift_1|0.5707|[0.5255, 0.6163]|
|fixed_modified_blur|0.4768|[0.3901, 0.5634]|
|fixed_modified_ink_spread|0.2996|[0.2377, 0.3659]|

## Methodology alignment
Aligned to manuscript §3.1 optical reconstruction and permitted observation; §3.2 computational observer surrogate; §3.3 severity-conditioned soundness and observational equivalence; §3.4 separate simulation from prospective physical/human validation. The paper’s 539-real + 7-synthetic full benchmark is NOT met by this eight-image pilot. No issuer-to-optical authorization mapping or cryptographic reduction is established.

## Limitations and decision
- No actual printed overlays or participant responses.
- No psychophysical calibration, real-world viewing geometry, semantic recognition, or empirically measured FAR/FRR.
- An instrumented oracle metric is included solely for diagnosis.
- Fixed-mask alterations may be infeasible to an adversary under the stated access structure.
- One eight-image pilot is insufficient for manuscript-scale generalization.

**Final status: PILOT_COMPUTATIONAL_EVIDENCE_ONLY; NO_SECURITY_QUALIFIED_CONSTRUCTION.**

## Sources
- Naor and Shamir, Visual Cryptography, https://doi.org/10.1007/BFb0053419
- NIST FIPS 204, https://doi.org/10.6028/NIST.FIPS.204
