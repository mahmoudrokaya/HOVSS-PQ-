#!/usr/bin/env python3
"""EOW C16 v2: A--F, source-linked, SYNTHETIC uncalibrated computational experiment.
Python >=3.10; numpy, Pillow. No human or physical claims.
"""
import argparse,csv,hashlib,io,json,math,platform,zipfile
from pathlib import Path
import numpy as np
from PIL import Image,ImageFilter

CONDITIONS=('original_ideal','original_shift_1','original_shift_3','original_rotate_1deg','original_wrong_partner','fixed_modified_ideal','fixed_modified_shift_1','fixed_modified_blur','fixed_modified_ink_spread')

def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def writecsv(path,rows,fields=None):
 if not rows:return
 with open(path,'w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
def readimg(z,path):return np.asarray(Image.open(io.BytesIO(z.read(path))).convert('L'))
def index(z):
 out={}
 for p in z.namelist():
  if p.endswith('/reference_binary_secret.png'):
   sid=next((v for v in reversed(p.split('/')[:-1]) if v.isdigit()),p.split('/')[-2])
   if sid in out:raise ValueError('Duplicate sample ID '+sid)
   out[sid]=p.rsplit('/',1)[0]+'/'
 return out

def extract_share(z,p,w,h):
 im=readimg(z,p);H,W=im.shape;candidates=[]
 for cell in range(2,33):
  dx=W-2*w*cell;dy=H-h*cell
  if min(dx,dy)<0 or dx%2 or dy%2:continue
  mx=dx//2;my=dy//2
  a=im[my+cell//2:my+h*cell:cell,mx+cell//2:mx+2*w*cell:cell]
  if a.shape==(h,2*w):
   bits=a<128;score=float(np.mean(bits.reshape(h,w,2).sum(2)==1));candidates.append((score,cell,bits))
 if not candidates:raise ValueError('Cannot locate share grid: '+p)
 score,cell,bits=max(candidates,key=lambda x:(x[0],x[1]))
 if score<.999:raise ValueError(f'Share subpixel structure invalid: {p} ({score})')
 return bits

def decode(a,b):return (a|b).reshape(a.shape[0],a.shape[1]//2,2).all(2)
def fixed_b(a,s):return np.where(np.repeat(s,2,axis=1),~a,a)
def shift(im,dx,dy):
 out=np.zeros_like(im);h,w=im.shape;x0=max(0,-dx);x1=min(w,w-dx);y0=max(0,-dy);y1=min(h,h-dy)
 if x1>x0 and y1>y0:out[y0+dy:y1+dy,x0+dx:x1+dx]=im[y0:y1,x0:x1]
 return out

def load_samples(original,modified):
 data={}
 with zipfile.ZipFile(original) as z0,zipfile.ZipFile(modified) as z1:
  i0=index(z0);i1=index(z1);common=sorted(set(i0)&set(i1),key=lambda x:int(x) if x.isdigit() else x)
  if not common:raise ValueError('No matched sample IDs in input archives')
  for sid in common:
   p0=i0[sid];p1=i1[sid];s0=readimg(z0,p0+'reference_binary_secret.png')<128;s1=readimg(z1,p1+'reference_binary_secret.png')<128
   if s0.shape!=s1.shape:raise ValueError('Mismatched secret dimensions '+sid)
   h,w=s0.shape;a=extract_share(z0,p0+'share_A_preview.png',w,h);b=extract_share(z0,p0+'share_B_preview.png',w,h)
   if not np.array_equal(decode(a,b),s0):raise ValueError('C13 original reconstruction failed '+sid)
   b1=fixed_b(a,s1)
   if not np.array_equal(decode(a,b1),s1):raise ValueError('Fixed-mask reconstruction failed '+sid)
   data[sid]=dict(s0=s0,s1=s1,a=a,b=b,b1=b1,changes=int(np.count_nonzero(s0^s1)),pixels=s0.size)
 return data

def render(a,b,condition,scale,blur_px,rotation_deg,spread):
 A=np.repeat(np.repeat(a.astype(np.uint8)*255,scale,0),scale,1)
 B=np.repeat(np.repeat(b.astype(np.uint8)*255,scale,0),scale,1)
 if condition.endswith('shift_1'):B=shift(B,scale,0)
 elif condition.endswith('shift_3'):B=shift(B,3*scale,0)
 elif condition.endswith('rotate_1deg'):
  B=np.asarray(Image.fromarray(B).rotate(rotation_deg,resample=Image.Resampling.BILINEAR,expand=False,fillcolor=0))
 # OR represents opaque ink; simplified digital rendering, not calibrated physical transmission.
 overlay=np.maximum(A,B).astype(np.uint8)
 if condition.endswith('blur'):overlay=np.asarray(Image.fromarray(overlay).filter(ImageFilter.GaussianBlur(blur_px)))
 if condition.endswith('ink_spread'):overlay=np.asarray(Image.fromarray(overlay).filter(ImageFilter.MaxFilter(spread)))
 return overlay

def blind_features(img):
 # NO access to original secret, labels, expected image or hidden template.
 f=img.astype(np.float32)/255.;im=Image.fromarray(img)
 # Multi-scale band energy; only pixels visible to the observer.
 coarse=np.asarray(im.resize((max(2,im.width//12),max(2,im.height//12)),Image.Resampling.BILINEAR),dtype=np.float32)/255
 fine=np.asarray(im.filter(ImageFilter.GaussianBlur(1.5)),dtype=np.float32)/255
 gx=np.abs(np.diff(coarse,axis=1)).mean();gy=np.abs(np.diff(coarse,axis=0)).mean()
 return dict(contrast=float(np.clip(2*np.std(f),0,1)),lowfreq_structure=float(np.clip((gx+gy)*3,0,1)),ink_fraction=float(f.mean()),local_stability=float(np.clip(1-np.abs(f-fine).mean(),0,1)))

def oracle_feature(img,s):
 # Privileged comparator, explicitly forbidden as a human-only verification result.
 ref=np.repeat(np.repeat(np.repeat(s.astype(np.uint8)*255,2,axis=1),img.shape[0]//s.shape[0],axis=0),img.shape[1]//(2*s.shape[1]),axis=1)
 return float(1-np.abs(img.astype(np.float32)-ref.astype(np.float32)).mean()/255)

def logistic(x):return float(1/(1+np.exp(-np.clip(x,-35,35))))
def simulate_observers(stimuli,nobs,nrep,seed,regime,output):
 rng=np.random.default_rng(seed);pars=[];trials=[]
 # Priors are illustrative, not fitted or representative of actual people.
 regime_scale={'conservative':0.65,'nominal':1.0,'optimistic':1.35}[regime]
 for j in range(nobs):
  pars.append(dict(observer_id=f'V{j+1:03d}',sensitivity=float(rng.lognormal(0,.22)*regime_scale),criterion=float(rng.normal(.56,.06)),lapse=float(rng.uniform(.005,.06)),noise_sd=float(rng.uniform(.03,.09)),bias=float(rng.normal(0,.045)),fatigue_slope=float(rng.uniform(0,.00003))))
 for si,s in enumerate(stimuli):
  for ob in pars:
   for rep in range(nrep):
    # Blind evidence depends ONLY on stimulus-derived features and hypothetical observer parameters.
    f=.35*s['contrast']+.45*s['lowfreq_structure']+.20*s['local_stability']
    e=ob['sensitivity']*f-ob['criterion']+ob['bias']-ob['fatigue_slope']*si*nrep+float(rng.normal(0,ob['noise_sd']))
    prob=ob['lapse']*.5+(1-ob['lapse'])*logistic(e/.12)
    accept=int(rng.random()<prob)
    # Not semantic object recognition: no class labels or human-trained recognition model.
    confidence=int(np.clip(round(1+4*abs(prob-.5)*2+float(rng.normal(0,.5))),1,5))
    latency=float(np.clip(rng.lognormal(math.log(2+3*(1-abs(2*prob-1))),.35),.2,30))
    trials.append(dict(evidence_type='SYNTHETIC_UNCALIBRATED',seed=seed,regime=regime,sample=s['sample'],condition=s['condition'],observer_id=ob['observer_id'],repetition=rep+1,accept=accept,confidence_1_5=confidence,response_time_seconds=round(latency,4),model_accept_probability=round(prob,7)))
 writecsv(output/'D_observer_parameters.csv',pars);writecsv(output/'D_synthetic_trials.csv',trials)
 return trials

def cluster_ci(trials,seed):
 rng=np.random.default_rng(seed+10000);out=[]
 for cond in CONDITIONS:
  rr=[r for r in trials if r['condition']==cond];obs=sorted(set(r['observer_id'] for r in rr));imgs=sorted(set(r['sample'] for r in rr))
  mat={(o,i):[int(r['accept']) for r in rr if r['observer_id']==o and r['sample']==i] for o in obs for i in imgs}
  means=[]
  for _ in range(250):
   so=rng.choice(obs,len(obs),replace=True);si=rng.choice(imgs,len(imgs),replace=True)
   values=[v for o in so for i in si for v in mat[(o,i)]]
   means.append(float(np.mean(values)))
  out.append(dict(condition=cond,synthetic_trials=len(rr),accept_rate=float(np.mean([int(r['accept']) for r in rr])),cluster_bootstrap_low=float(np.quantile(means,.025)),cluster_bootstrap_high=float(np.quantile(means,.975)),uncertainty_type='SIMULATED_OBSERVER_AND_IMAGE_CLUSTER_BOOTSTRAP_NOT_EMPIRICAL'))
 return out

def prior_evidence(args,out):
 """Read earlier experiment outputs for traceability; never feed labels into blind decisions."""
 audit={}
 for name,path in [('C13_cross_version',args.cross),('C14_human_study',args.c14),('C16_v1_baseline',args.c16_v1),('C12_prior_candidate',args.c12)]:
  if not path:continue
  pp=Path(path)
  if not pp.is_file():raise FileNotFoundError(f'{name}: {pp}')
  info={'path':str(pp),'sha256':sha(pp),'role':'HISTORICAL_COMPARATOR_NOT_OBSERVER_INPUT'}
  with zipfile.ZipFile(pp) as z:
   names=z.namelist();info['file_count']=len(names)
   info['recognized_files']=[x for x in names if x.endswith(('summary.json','manifest.json','cross_version_metrics.csv','condition_summary.csv','PARTICIPANT_RESPONSES_BLINDED.csv','study_manifest.json'))][:25]
   if name=='C14_human_study':
    response=next((x for x in names if x.endswith('PARTICIPANT_RESPONSES_BLINDED.csv')),None)
    if response:
     rows=list(csv.DictReader(io.StringIO(z.read(response).decode('utf-8-sig'))))
     info['planned_response_rows']=len(rows)
     info['rows_with_any_response']=sum(any(str(v).strip() for k,v in row.items() if k in ('response_valid','recognized_image','confidence_1_5','time_seconds')) for row in rows)
     info['human_observations_inferred']=False
   if name=='C16_v1_baseline':
    fn=next((x for x in names if x.endswith('condition_summary.csv')),None)
    if fn:
     rr=list(csv.DictReader(io.StringIO(z.read(fn).decode('utf-8-sig'))));info['v1_condition_summary']=rr
  audit[name]=info
 (out/'G_prior_experiment_evidence.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
 return audit

def run(args):
 out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 for p in (args.original,args.modified):
  if not Path(p).is_file():raise FileNotFoundError(str(p))
 historical=prior_evidence(args,out)
 samples=load_samples(args.original,args.modified);ids=list(samples);audit=[];stimuli=[];attack=[];previews=out/'C_optical_previews';previews.mkdir(exist_ok=True)
 for idx,sid in enumerate(ids):
  d=samples[sid];s0=d['s0'];s1=d['s1'];a=d['a'];b=d['b'];b1=d['b1']
  audit.append(dict(sample=sid,source='C13_ORIGINAL_AND_MODIFIED_ZIPS',binary_pixels=d['pixels'],changed_binary_pixels=d['changes'],binary_change_fraction=d['changes']/d['pixels'],original_exact=int(np.array_equal(decode(a,b),s0)),fixed_mask_exact=int(np.array_equal(decode(a,b1),s1)),unchanged_secret=int(d['changes']==0)))
  # Real wrong-partner B when dimensions match; otherwise independently generated mismatched mask, clearly tagged.
  candidates=[v for v in ids if v!=sid and samples[v]['b'].shape==b.shape]
  if candidates:wrong=samples[candidates[0]]['b'];wrong_source='DIFFERENT_SAMPLE_'+candidates[0]
  else:
   rr=np.random.default_rng(args.seed+int(sid) if sid.isdigit() else args.seed+idx)
   wrong=rr.integers(0,2,size=b.shape).astype(bool);wrong_source='INDEPENDENT_RANDOM_SHARE_SURROGATE'
  for cond in CONDITIONS:
   current=wrong if cond=='original_wrong_partner' else (b1 if cond.startswith('fixed_') else b)
   img=render(a,current,cond,args.scale,args.blur,args.rotation,args.spread)
   feat=blind_features(img)
   Image.fromarray(255-img).save(previews/f'{sid}_{cond}.png')
   truth='legitimate' if cond.startswith('original_') and cond!='original_wrong_partner' else ('wrong_partner' if cond=='original_wrong_partner' else 'fixed_mask_modified')
   if cond in ('original_shift_1','original_shift_3','original_rotate_1deg'):truth='benign_misalignment'
   stim=dict(sample=sid,condition=cond,condition_class=truth,**feat,oracle_template_agreement=oracle_feature(img,s0),oracle_role='INSTRUMENTED_ONLY_NOT_USED_BY_BLIND_OBSERVER',binary_changes=d['changes'],wrong_partner_source=wrong_source if cond=='original_wrong_partner' else '')
   stimuli.append(stim)
   if cond=='fixed_modified_ideal':attack.append(dict(sample=sid,attack='FIXED_MASK_CONTENT_ALTERATION_CONTROL',binary_changes=d['changes'],actual_content_changed=int(d['changes']>0),severity=d['changes']/d['pixels'],same_observation_as_original=int(d['changes']==0),attacker_feasibility='NOT_ESTABLISHED_REQUIRES_TRUST_BOUNDARY'))
 writecsv(out/'A_exact_reconstruction_audit.csv',audit);writecsv(out/'B_blind_vs_oracle_features.csv',stimuli);writecsv(out/'C_optical_stimulus_metrics.csv',stimuli);writecsv(out/'E_attack_severity.csv',attack)
 trials=simulate_observers(stimuli,args.observers,args.repetitions,args.seed,'nominal',out)
 stats=cluster_ci(trials,args.seed);writecsv(out/'F_cluster_uncertainty.csv',stats)
 sensitivity=[]
 for regime in ('conservative','nominal','optimistic'):
  for cond in CONDITIONS:
   ss=[s for s in stimuli if s['condition']==cond];base=float(np.mean([.35*s['contrast']+.45*s['lowfreq_structure']+.20*s['local_stability'] for s in ss]))
   for criterion in (.48,.56,.64):
    # Expected acceptance under parameter sweep, NOT fitted data or human predictions.
    sensitivity.append(dict(regime=regime,condition=cond,criterion=criterion,expected_acceptance=logistic(({'conservative':.65,'nominal':1.,'optimistic':1.35}[regime]*base-criterion)/.12),evidence_type='UNCALIBRATED_PARAMETER_SWEEP'))
 writecsv(out/'F_parameter_sensitivity.csv',sensitivity)
 manifest=dict(experiment='EOW_C16_V2_A_TO_F',status='COMPUTATIONAL_SIMULATION_ONLY',inputs={'original':str(args.original),'modified':str(args.modified),'sha256_original':sha(args.original),'sha256_modified':sha(args.modified)},sample_ids=ids,prior_evidence_archives=list(historical),conditions=list(CONDITIONS),observers=args.observers,repetitions=args.repetitions,synthetic_trials=len(trials),seed=args.seed,python=platform.python_version(),numpy=np.__version__,pillow=Image.__version__,optics=dict(display_scale=args.scale,blur_radius=args.blur,rotation_degrees=args.rotation,ink_spread_filter=args.spread,units='SIMULATED_DISPLAY_PIXELS_NOT_PHYSICAL_MM'),observer_model=dict(status='UNCALIBRATED',model='multiscale contrast/structure + stochastic criterion and lapses',observer_sensitivity='lognormal(0,0.22)',criterion='normal(0.56,0.06)',lapse='uniform(0.005,0.06)',noise='uniform(0.03,0.09)',bias='normal(0,0.045)',fatigue='uniform(0,0.00003)',latency='heuristic lognormal not fitted'),real_human_observations=0,physical_measurements=0,issuer_to_optical_binding_verified=False,security_qualified=False)
 (out/'F_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
 lines=['# EOW_C16 v2 — Integrated experiments A–F','', '**Evidence classification: UNCALIBRATED DIGITAL SIMULATION; NOT PHYSICAL OR HUMAN VALIDATION.**','',f"Inputs: {len(ids)} matched C13 images, {len(CONDITIONS)} conditions, {args.observers} synthetic observers, {args.repetitions} repetitions; **{len(trials):,} synthetic decisions**.",'','## A. Reconstruction correctness',f"Original and fixed-mask reconstructions pass: {sum(x['original_exact'] and x['fixed_mask_exact'] for x in audit)}/{len(audit)}. Changed binary secrets: {sum(x['changed_binary_pixels'] for x in audit)} pixels; unchanged binary secrets: {sum(x['unchanged_secret'] for x in audit)} images.",'','## B. Protocol-constrained observer','The stochastic decision model uses ONLY blind image-derived features; an oracle similarity comparator is stored separately and never passed into the decision model. The blind features are NOT validated semantic object recognition or measured human perception.','', '## C. Optical model','Digital OR overlay with subpixel translation, rotation, blur and dilation. Scale, transmission, lighting, and film physics are NOT calibrated to real hardware. Nonmonotonic shift responses may arise from two-subpixel periodic geometry.','', '## D. Behavioral variability','100 observer parameter vectors (default) and all synthetic decisions saved. Priors, confidence, and response time are assumptions, not human-fitted distributions.','', '## E. Adversarial severity','Fixed-mask B1 uses original A and modified binary secret. This is a controlled content perturbation, NOT necessarily an attacker-feasible forgery. Source modifications erased by binarization yield indistinguishable observations. Wrong-partner controls are not proof of cryptographic authentication.','', '## F. Sensitivity and uncertainty','Observer/image clustered bootstrap describes variability inside the synthetic model, NOT empirical confidence in human FAR/FRR. Parameter sweep demonstrates model dependence. No physical/human gate is passed.','', '## Synthetic acceptance summary','|Condition|Rate|Model-only cluster interval|','|---|---:|---:|']
 for x in stats:lines.append(f"|{x['condition']}|{x['accept_rate']:.4f}|[{x['cluster_bootstrap_low']:.4f}, {x['cluster_bootstrap_high']:.4f}]|")
 lines+=['','## Methodology alignment','Aligned to manuscript §3.1 optical reconstruction and permitted observation; §3.2 computational observer surrogate; §3.3 severity-conditioned soundness and observational equivalence; §3.4 separate simulation from prospective physical/human validation. The paper’s 539-real + 7-synthetic full benchmark is NOT met by this eight-image pilot. No issuer-to-optical authorization mapping or cryptographic reduction is established.','', '## Limitations and decision','- No actual printed overlays or participant responses.','- No psychophysical calibration, real-world viewing geometry, semantic recognition, or empirically measured FAR/FRR.','- An instrumented oracle metric is included solely for diagnosis.','- Fixed-mask alterations may be infeasible to an adversary under the stated access structure.','- One eight-image pilot is insufficient for manuscript-scale generalization.','', '**Final status: PILOT_COMPUTATIONAL_EVIDENCE_ONLY; NO_SECURITY_QUALIFIED_CONSTRUCTION.**','', '## Sources','- Naor and Shamir, Visual Cryptography, https://doi.org/10.1007/BFb0053419','- NIST FIPS 204, https://doi.org/10.6028/NIST.FIPS.204']
 (out/'F_complete_evidence_report.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
 print(json.dumps(dict(status=manifest['status'],samples=len(ids),conditions=len(CONDITIONS),synthetic_trials=len(trials),output=str(out),exact_reconstruction=sum(x['original_exact'] and x['fixed_mask_exact'] for x in audit)),indent=2))

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--original',required=True);p.add_argument('--modified',required=True);p.add_argument('--output',required=True);p.add_argument('--observers',type=int,default=100);p.add_argument('--repetitions',type=int,default=10);p.add_argument('--seed',type=int,default=20261116);p.add_argument('--scale',type=int,default=3);p.add_argument('--blur',type=float,default=1.5);p.add_argument('--rotation',type=float,default=1.0);p.add_argument('--spread',type=int,default=3)
 p.add_argument('--cross',help='Optional C13 cross-version audit ZIP');p.add_argument('--c14',help='Optional C14 prepared-study ZIP');p.add_argument('--c16-v1',help='Optional previous C16 output ZIP');p.add_argument('--c12',help='Optional C12 candidate-evaluation ZIP')
 a=p.parse_args()
 if min(a.observers,a.repetitions,a.scale)<1 or a.spread<3 or a.spread%2!=1:raise ValueError('Invalid simulation parameters')
 run(a)
if __name__=='__main__':main()
