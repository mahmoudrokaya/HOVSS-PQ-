# EOW C12 — Constrained Architecture Comparison

Processed 549/549 images; 7 conditions; 4 candidates.
Operational thresholds: FRR <= 0.050, FAR <= 0.050.

| Candidate | Passed conditions | Mean FRR | Mean attack acceptance | Human-only optical |
|---|---:|---:|---:|---|
| registration_exact | 3/7 | 0.5040 | 0.0003 | No |
| reference_exact | 3/7 | 0.5714 | 0.0000 | No |
| digital_digest | 3/7 | 0.5714 | 0.0000 | No |
| reference_99 | 0/7 | 0.5714 | 0.4286 | No |

## Scientific interpretation

This experiment compares explicit architectural baselines, not a new security-qualified visual authentication construction.
All four candidates rely on a trusted digital reference image or digest. The digital digest is neither an ML-DSA signature nor a human optical method.
The bounded-registration candidate tests a narrow engineering improvement, not a general geometric registration solution.
An architecture is not credited for detecting attacks when it rejects legitimate samples. Both FRR and FAR must satisfy the configured limits in each condition.
One changed subpixel is not an adaptive optimal attacker; security must be re-tested against C09-style adaptive strategies and stronger modifications.
Privacy, physical optical performance, unaided human verification, and post-quantum issuer binding remain separate unresolved or upstream questions.

## References

- Naor and Shamir, Visual Cryptography: https://doi.org/10.1007/BFb0053419
- NIST FIPS 204: https://doi.org/10.6028/NIST.FIPS.204
