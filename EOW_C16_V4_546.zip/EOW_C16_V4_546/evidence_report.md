# EOW C16 V4 — Full digital benchmark

**Evidence classification: synthetic digital simulation; no empirical human calibration.**

- Images: 546 unique decodable images (input-order selected; audit manifest).
- Optical stimuli: 4914 (9 per image).
- Synthetic decisions: 4,914,000 (100 observers × 10 repetitions per stimulus).
- Leave-one-image-out supervised digital classifier ROC-AUC: 0.9982; balanced accuracy: 0.9982.
- Fixed-mask alterations: 1.00% of binary pixels; digital reconstruction checks passed for all images.

## Important limitations

The simulated observer parameters are assumed, not estimated from humans. The held-out classifier is supervised on synthetic condition labels and is not a human model. The altered secret is produced by controlled flips, not necessarily an attacker-feasible manipulation. The shift implementation uses periodic wrapping and is not a physical registration model; rotations/blur are illustrative raster operations. No issuer-to-optical authentication proof is supplied. The input selection is the first 546 decodable SHA256-unique images in sorted path order, not an externally verified real/synthetic provenance stratification.

**Human data required:** use the separately provided prospective study templates and calibration command.
