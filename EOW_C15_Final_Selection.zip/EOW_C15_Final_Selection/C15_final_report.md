# EOW_C15 — Final Selection and Reporting

## Decision

**Security-qualified construction: NONE.**

**Prototype for further physical feasibility testing:** C13 printable OR-VSS, selected solely because its digital reconstruction and printable artifacts are available. This is **not** a security endorsement or proof of superiority.

## Audited attached evidence

- C13 ideal digital samples: **8**; total ideal reconstruction pixel errors: **0**.
- Mean binary-secret change: **0.0681%**.
- Independently regenerated cross-version A0+B1 error: **49.3550%**; A1+B0: **49.3414%**. These do not measure tamper detection.
- C13/C14 alignment manifest: **21** conditions, not measured physical outcomes.
- C14 planned participants: **12**; planned trials: **288**; response rows containing observations: **0**.
- Verified physical captures recorded in C13 ideal metrics: **0**.
- Ethics clearance documented in supplied checklist: **NO**.

## C12 candidate screening (historical summaries only)

The four C12 variants (Reference-99, Reference-Exact, Registration-Exact, Digital-Digest) were previously reported not to meet both FAR ≤ 5% and FRR ≤ 5% in all seven conditions. Their underlying raw C12 results are **not** supplied here, so these are carried forward as prior-study conclusions, not independently revalidated C15 calculations.

## Interpretation and decision boundaries

Exact ideal digital reconstruction does not demonstrate physical usability, human recognition, tamper detection, authentication, or post-quantum security. In particular, large cross-version differences caused by independent random masks are a confounder. A cryptographic enrollment signature can protect digital records without proving that unaided optical overlay reveals tampering.

## Evidence required before stronger claims

1. Perform a documented physical print-and-overlay pilot with calibration measurements, photos, and failures.
2. Obtain institutional ethics approval or exemption, then collect genuine participant responses under a blinded protocol.
3. Independently evaluate aligned, wrong-partner, and misregistered conditions; report FAR/FRR with uncertainty and participant-level dependence.
4. Perform a fixed-mask controlled alteration test, retaining A0 while recomputing B1, to isolate content change from independent randomization.
5. Reaudit original C12 raw metrics and prespecified security thresholds before any final architecture recommendation.

**Final research verdict: `NO_SECURITY_QUALIFIED_CONSTRUCTION`.**
