# EOW_C08 — Real ML-DSA-65 Enrollment Audit

**Execution:** PASS; **tests:** 15/15.
**OpenSSL:** OpenSSL 4.1.0 23 Oct 2026 (Library: OpenSSL 4.1.0 23 Oct 2026).
**Signature size:** 3309 bytes.

## Adversarial cases

| Case | Expected | Observed | Reason |
|---|---|---|---|
| legitimate | True | True | ACCEPT |
| modified_share | False | False | SHARE_BINDING |
| modified_record | False | False | INVALID_SIGNATURE |
| modified_digest | False | False | SHARE_BINDING |
| modified_issuer | False | False | ISSUER_IDENTITY |
| modified_enrollment_id | False | False | ENROLLMENT_IDENTITY |
| modified_revision | False | False | INVALID_SIGNATURE |
| truncated_signature | False | False | INVALID_SIGNATURE |
| random_signature | False | False | INVALID_SIGNATURE |
| rogue_public_key | False | False | UNTRUSTED_PUBLIC_KEY |
| rogue_signature | False | False | INVALID_SIGNATURE |
| stale_revision | False | False | STALE_REVISION |
| revoked_enrollment | False | False | REVOKED_OR_UNKNOWN_ENROLLMENT |
| exact_replay | True | True | ACCEPT |
| authorized_reissuance | True | True | ACCEPT |

## Security boundary

A verified signature binds the *digital* enrollment record and its issued-share digest to the pinned issuer key.
It does not establish that a physical transparency is the signed share, that an unaided observer authenticates the issuer, or that OR-stacking forgery resistance is achieved.
A trusted external revocation/freshness state is necessary to reject an exact replay when freshness is required.
Private keys are temporary TEST-ONLY keys and are not exported.

## References

- [NIST FIPS 204](https://doi.org/10.6028/NIST.FIPS.204)
- [OpenSSL pkeyutl ML-DSA documentation](https://docs.openssl.org/3.5/man1/openssl-pkeyutl/)
