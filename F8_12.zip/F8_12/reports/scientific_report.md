# HOVSS-PQ: Evidence-Gated Selection and Reporting

**Status:** Computational experiments completed; complete HOVSS-PQ feasibility NOT ESTABLISHED.

## Evidence and reproducibility

- Dataset images reported by F8_09_REVISED: 546
- F8_09_REVISED trial records: 294840
- Primary full-image benchmark: F8_09_REVISED, not the superseded F8_09.
- F8_07 executes real electronic ML-DSA; F8_09_REVISED uses an ideal digital control.
- F8_10 uses numerical perturbations, not calibrated physical measurements.
- F8_11 produces protocol materials; no human performance is inferred from preparation.

## Feasibility gates

| Gate | Status | Basis |
|---|---|---|
| G1 Dataset and computational pipeline | PASS | F8_01 manifest, F8_09_REVISED and F8_10 execution verdicts |
| G2 Electronic post-quantum issuer signatures | PASS_ELECTRONIC_ONLY | F8_07 actual ML-DSA-65 verification; no optical issuer binding implied |
| G3 Perfect secrecy of complete proposed construction | NOT_ESTABLISHED | Classical baseline privacy does not prove secrecy of public anchors, references or full system |
| G4 Human-observable issuer-bound authentication | NOT_ESTABLISHED | No demonstrated optical encoding of issuer authorization; electronic signature alone is insufficient |
| G5 Physical optical fabrication and tolerance | NOT_MEASURED | F8_10 perturbations are simulated; F8_11 is a preparation protocol |
| G6 Human-observer discrimination | NOT_PERFORMED | F8_11 preparation audit; presence of responses alone is not evidence of success |
| G7 Static exact-copy replay prevention | NOT_ESTABLISHED | Exact copies cannot be distinguished by static optical observations or signatures without freshness |
| G8 Complete HOVSS-PQ feasibility | NOT_ESTABLISHED | G3–G7 are not satisfied; do not infer full feasibility from G1 or G2 |

## Candidate selection (no security-certified winner)

| Candidate | Classification | Primary limitation |
|---|---|---|
| A Public lattice-derived anchor | NEGATIVE_CONTROL | Public recomputation allows rebinding; optical issuer authenticity absent |
| B Protected enrolled reference | CONDITIONAL_RESEARCH_CANDIDATE | Reference substitution/custody; trusted_layers is an ideal digital comparator |
| C Jones polarization differential | CONDITIONAL_RESEARCH_CANDIDATE | Threshold robustness fails under blur/translation/fabrication surrogate |
| D ML-DSA electronic verifier | ELECTRONIC_POSITIVE_CONTROL | Requires electronic verification; not human-only optical authentication |

**Selection rule:** No candidate passes all required security and physical-human gates. Candidate C remains a research direction for optical distinguishability, B for reference-dependent verification, A a negative control, and D a digital positive control. No ranking of full-system security is justified.

## Selected held-out attack acceptance rates

F8_09_REVISED, `split=test`, threshold 0.02. Rates are computational, not human observations.

| Model | Single-subpixel | Adaptive search | Exact copy |
|---|---:|---:|---:|
| or | 100.00% | 100.00% | 100.00% |
| public_anchor | 100.00% | 100.00% | 100.00% |
| trusted_stack | 100.00% | 100.00% | 100.00% |
| trusted_layers | 0.00% | 0.00% | 100.00% |
| polarization | 0.00% | 0.00% | 100.00% |
| signed_digital | 0.00% | 0.00% | 100.00% |

## Interpretation and unresolved work

1. Validate whole-construction confidentiality including references and public side information.
2. Specify and prove a secure issuer-to-optical binding, or narrow the claim to electronic authentication.
3. Measure actual fabricated optical specimens and predefine operating tolerances.
4. Obtain applicable ethics approval, conduct blinded human studies, and analyze actual responses.
5. Address reference custody and static replay/freshness limitations.
6. Avoid equating an ideal digital layer comparator with unaided human verification.

## References

- Naor-Shamir visual cryptography: https://doi.org/10.1007/BFb0053419
- NIST FIPS 204 ML-DSA: https://doi.org/10.6028/NIST.FIPS.204
- WMA Declaration of Helsinki: https://www.wma.net/policies-post/wma-declaration-of-helsinki/

## Evidence inventory

| Source | Present | SHA-256 |
|---|---|---|
| F8_01_dataset | True | `72124943fae55cae` |
| F8_02_verdict | True | `38295edf77b9b39e` |
| F8_03_verdict | True | `707ca97b5d764347` |
| F8_04_verdict | True | `b975a2e2d423deeb` |
| F8_05_verdict | True | `999182205edbec19` |
| F8_06_verdict | True | `6ea9d963a1cecf74` |
| F8_07_verdict | True | `66a5535eee64c385` |
| F8_07_crypto | True | `56b6465fd8099480` |
| F8_08_verdict | True | `1e94134c3fc5f7c0` |
| F8_09_revised_verdict | True | `ea4c607cf32f5783` |
| F8_09_revised_summary | True | `810598fc0288b69f` |
| F8_09_revised_attack_summary | True | `28c2e7cf6d28da19` |
| F8_10_verdict | True | `938e901b3a4dde5e` |
| F8_10_robustness | True | `109b0893f0015da8` |
| F8_10_summary | True | `35bddae3dc30f5cf` |
| F8_11_preparation | True | `947364df1b6f833d` |
