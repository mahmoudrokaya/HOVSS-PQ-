# EOW_C05 Integrated Witness — Scientific Report

**Verdict: NO_SECURITY_QUALIFIED_CONSTRUCTION.**

This is an exact small-domain and seeded-enrollment computational experiment, not a physical or human verification study.

## Models

1. Detached tag: a separable control.
2. Distributed keyed parity tags: tags depend on local B data but are checked only against their original public values, allowing transplantation.
3. Private spatial OR probe: a protected mask and trusted expected observation; ideal comparator, not a demonstrated unaided human operation.

## Attack enumeration

| Model | Observer | Accepted visible-content changes | Visible-content changes |
|---|---|---:|---:|
| detached_tag | exact_or | 14336 | 14336 |
| detached_tag | per_pixel_black_count | 14336 | 14336 |
| distributed_tag | exact_or | 14336 | 14336 |
| distributed_tag | per_pixel_black_count | 14336 | 14336 |
| private_spatial_probe | exact_or | 2031 | 14336 |
| private_spatial_probe | per_pixel_black_count | 3077 | 14336 |

## Privacy

Public observations are limited to share A and the published tag; no private witness state is exposed.
- detached_tag: public TV = 0.0; full-compromise TV = 1.0.
- distributed_tag: public TV = 0.0; full-compromise TV = 1.0.
- private_spatial_probe: public TV = 0.0; full-compromise TV = 1.0.

## Interpretation

Spatial distribution of keyed tags does not prevent an attacker from transplanting unchanged public tags while modifying the share data.
A private OR probe can detect some alterations but necessarily masks selected subpixels and suffers collisions; exact and black-count observers may differ.
No mechanism here establishes simultaneous confidentiality, optical issuer authenticity, robust human verification, and replay resistance.

## References

- [Naor and Shamir, Visual Cryptography](https://doi.org/10.1007/BFb0053419)
- [NIST FIPS 204](https://doi.org/10.6028/NIST.FIPS.204)
