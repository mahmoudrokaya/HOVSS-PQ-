# EOW C11 — Simulated Optical Robustness

Processed 549/549 source images across 13 conditions.
Agreement acceptance threshold: 0.9900.
Elapsed time: 7.08 s.

| Condition | Images | Benign pixel error | False rejection | Attack acceptance |
|---|---:|---:|---:|---:|
| ideal | 549 | 0.00000 | 0.00000 | 1.00000 |
| shift_1 | 549 | 0.74919 | 1.00000 | 0.00000 |
| shift_2 | 549 | 0.49825 | 1.00000 | 0.00000 |
| rotate_1 | 549 | 0.44752 | 1.00000 | 0.00000 |
| rotate_3 | 549 | 0.49499 | 1.00000 | 0.00000 |
| scale_098 | 549 | 0.48709 | 1.00000 | 0.00000 |
| scale_102 | 549 | 0.49444 | 1.00000 | 0.00000 |
| blur_08 | 549 | 0.10869 | 1.00000 | 0.00000 |
| blur_15 | 549 | 0.44081 | 1.00000 | 0.00000 |
| contrast_070 | 549 | 0.00000 | 0.00000 | 1.00000 |
| brightness_080 | 549 | 0.00000 | 0.00000 | 1.00000 |
| noise_010 | 549 | 0.00000 | 0.00000 | 1.00000 |
| noise_030 | 549 | 0.04800 | 1.00000 | 0.00000 |

## Interpretation
The comparison uses a trusted clean image and a software pixel-agreement rule. This is not unaided human optical verification.
A single-pixel content change can pass a 99% whole-image agreement threshold even with no perturbation. This is an intentionally weak illustrative verifier, not a proposed secure design.
Benign distortion may cause false rejection, while distortion may also mask content changes. Results are simulation-only and depend on image size and threshold.
No print/scan, real transparency alignment, human observer, or post-quantum cryptographic operation was performed.

## References
- Naor and Shamir, Visual Cryptography: https://doi.org/10.1007/BFb0053419
- NIST FIPS 204: https://doi.org/10.6028/NIST.FIPS.204
