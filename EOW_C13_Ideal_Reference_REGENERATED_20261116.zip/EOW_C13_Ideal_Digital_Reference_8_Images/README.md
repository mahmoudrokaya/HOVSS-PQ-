# EOW_C13 — Ideal Digital Reference for Eight Uploaded Images

**All outputs are digitally simulated reference designs, NOT actual physical results.**

## Contents
Each `samples/<image ID>/` directory contains:
- `share_A_PRINT_100pct.pdf`, `share_B_PRINT_100pct.pdf`: paired A4 print layouts with cross registration marks and a 10 mm scale bar.
- `share_A_preview.png`, `share_B_preview.png`: preview images with consistent marker geometry.
- `ideal_aligned_overlay_preview.png`: pixel-perfect digital overlay, NOT a photograph.
- `reference_binary_secret.png`: thresholded reference image.
- `ideal_decoded_secret.png`: ideal digital decoding, NOT unaided human perception.
- `source_resized_color.png`, `comparison_guide.png`: visual guide.

## Procedure for real experiment
1. Print A and B PDFs on printer-compatible transparent film, at 100% actual size, disabling fit-to-page. Verify 10 mm bar using a physical ruler. Record actual bar length, printer, transparency film and any distortion.
2. Stack A and B transparencies and manually align all four cross centers. Use uniform backlighting. Photograph from perpendicular direction, ensuring all four crosses are visible. Repeat after independent realignment at least twice.
3. Save each real photograph separately; record its original path and cross centers in `captures_TEMPLATE.json` (make a working copy). Record measured scale, alignment time, lighting, camera, capture settings, and subjective visibility. Compare captured overlay to the ideal reference after geometric rectification. Never replace a real capture with an ideal digital overlay.

## Meaning of the ideal metrics
A zero pixel-error rate and 100% agreement follow by construction from the ideal OR-VSS encoding and exact alignment. They are **not** empirical estimates of printing fidelity, optical robustness, participant recognition, confidentiality, or malicious modification resistance. The printed images are not authenticated credentials.

## Model
- Grayscale conversion and threshold <128 (black); aspect ratio preserved, longest dimension <=64 pixels.
- Classical randomized two-share OR visual cryptography with horizontal 2-subpixel expansion.
- Ideal overlay is Boolean OR of aligned shares; decoding classifies each two-subpixel pair as black only if both are black.
- PDF geometry: A4, 1.0 mm subpixels, cross centers 3 subpixels beyond payload corners, 10 mm scale bar.
- The ideal decoded image is a software reconstruction using a reference-aligned decoder, **not** a human perception study.

## Security and validity
Research verdict: `NO_SECURITY_QUALIFIED_CONSTRUCTION`. No real captures, no physical measurements, no human participants, and no authentication experiments are represented in this package.

## Reference
Naor and Shamir, Visual Cryptography, https://doi.org/10.1007/BFb0053419
