# EOW_C13 — Physical Optical Reconstruction Feasibility

Purpose: measure whether printed share pairs can be physically overlaid and reconstructed.

This is NOT a security demonstration or a human authentication experiment.

Mode: generate

Summary:
```json
{
  "mode": "generate",
  "selected_source_images": 10,
  "generated_print_pairs": 10,
  "failed_source_images": 0,
  "average_generation_seconds": 0.029134919997886755,
  "real_physical_captures": 0,
  "physical_feasibility": "NOT_YET_TESTED",
  "research_verdict": "NO_SECURITY_QUALIFIED_CONSTRUCTION"
}
```

Print A/B PDF pages on transparent media at **100% actual size**, no fit-to-page. Check the 10 mm calibration bar. Align the four registration crosses, photograph the physical overlay with even lighting, then fill captures.json with actual capture_path and corners_px [TL,TR,BR,BL] of the OUTER registration square visible in the preview. Evaluation rectifies the image using those points. Manual registration introduces operator uncertainty.

Thresholds 96/128/160 are sensitivity checks, not calibrated psychophysical thresholds. The pixel-error comparison requires an electronic reference and is not unaided human verification.

No actual capture is counted without user-supplied image and registration metadata. No attack-resistance, privacy, or post-quantum verification claim is made.

References: Naor and Shamir, Visual Cryptography, https://doi.org/10.1007/BFb0053419 ; NIST FIPS 204, https://doi.org/10.6028/NIST.FIPS.204
