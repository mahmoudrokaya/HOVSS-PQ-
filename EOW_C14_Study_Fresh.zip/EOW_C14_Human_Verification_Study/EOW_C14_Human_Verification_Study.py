import argparse,csv,json,random,math,pathlib,hashlib
SAMPLES='2018 3063 5096 6046 8068 10081 14085 14092'.split()
CONDITIONS='valid_aligned wrong_partner misregistered'.split()
def save(path,rows,cols):
 with open(path,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore');w.writeheader();w.writerows(rows)
def load(path):
 with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def ci(k,n):
 if not n:return None
 z=1.96;p=k/n;d=1+z*z/n;m=(p+z*z/(2*n))/d;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d;return [m-h,m+h]
def prepare(a):
 out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=True);rng=random.Random(a.seed);rows=[]
 for i in range(a.participants):
  pid=f'P{i+1:03d}';trials=[]
  for sample in SAMPLES:
   for cond in CONDITIONS:
    other=SAMPLES[(SAMPLES.index(sample)+1+i%7)%8]
    pair=f'{sample}:A0+B0' if cond=='valid_aligned' else (f'{sample}:A0+{other}:B0' if cond=='wrong_partner' else f'{sample}:A0+B0:OFFSET')
    trials.append(dict(participant_id=pid,sample_id=sample,condition=cond,expected_valid=int(cond=='valid_aligned'),physical_pair_id=pair))
  rng.shuffle(trials)
  for j,t in enumerate(trials,1):
   tid=f'{pid}-T{j:02d}';t.update(trial_id=tid,sequence=j,condition_code=hashlib.sha256(f'{a.seed}|{tid}|{t["condition"]}'.encode()).hexdigest()[:8],response_valid='',recognized_image='',confidence_1_5='',time_seconds='',notes='');rows.append(t)
 save(out/'STAFF_RANDOMIZATION_KEY_PRIVATE.csv',rows,list(rows[0]))
 save(out/'STAFF_PAIR_SETUP.csv',rows,'participant_id trial_id sequence sample_id condition physical_pair_id condition_code'.split())
 save(out/'PARTICIPANT_RESPONSES_BLINDED.csv',rows,'participant_id trial_id sequence condition_code response_valid recognized_image confidence_1_5 time_seconds notes'.split())
 manifest={'status':'PLANNED_NOT_CONDUCTED','participants_planned':a.participants,'trials_per_participant':24,'trials_planned':len(rows),'seed':a.seed,'conditions':CONDITIONS,'samples':SAMPLES,'physical_captures':0,'human_observations':0}
 (out/'study_manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
def analyze(a):
 out=pathlib.Path(a.output);out.mkdir(parents=True,exist_ok=True);key={r['trial_id']:r for r in load(a.key)};responses=load(a.responses);rows=[];errors=[];seen=set()
 for r in responses:
  tid=r.get('trial_id','');v=r.get('response_valid','').strip().lower()
  if tid not in key or tid in seen:errors.append('unknown or duplicate trial '+tid);continue
  seen.add(tid)
  if not v:continue
  if v not in ['1','0','yes','no','true','false','valid','invalid']:errors.append('invalid response '+tid);continue
  pred=v in ['1','yes','true','valid'];actual=key[tid]['expected_valid']=='1'
  rows.append(dict(key[tid],prediction=int(pred),correct=int(pred==actual),response_valid=v,recognized_image=r.get('recognized_image',''),confidence_1_5=r.get('confidence_1_5',''),time_seconds=r.get('time_seconds','')))
 def stats(rs):
  n=len(rs);good=sum(x['correct'] for x in rs);valid=[x for x in rs if x['expected_valid']=='1'];invalid=[x for x in rs if x['expected_valid']=='0'];fr=sum(not x['prediction'] for x in valid);fa=sum(x['prediction'] for x in invalid)
  return dict(n=n,accuracy=good/n if n else None,accuracy_wilson95=ci(good,n),FAR=fa/len(invalid) if invalid else None,FAR_wilson95=ci(fa,len(invalid)),FRR=fr/len(valid) if valid else None,FRR_wilson95=ci(fr,len(valid)))
 report={'status':'OBSERVATIONS_RECORDED' if rows else 'NO_HUMAN_OBSERVATIONS','overall':stats(rows),'by_condition':{c:stats([x for x in rows if x['condition']==c]) for c in CONDITIONS},'participants':len(set(x['participant_id'] for x in rows)),'unanswered':len(key)-len(rows),'errors':errors,'warning':'Repeated trials within participants are correlated; trial-level Wilson intervals are descriptive only. Wrong-partner rejection does not prove integrity.'}
 (out/'analysis_summary.json').write_text(json.dumps(report,indent=2));save(out/'analyzed_trials.csv',rows,list(rows[0]) if rows else ['trial_id']);print(json.dumps(report,indent=2))
p=argparse.ArgumentParser();s=p.add_subparsers(dest='mode',required=True);a=s.add_parser('prepare');a.add_argument('--participants',type=int,default=12);a.add_argument('--seed',type=int,default=20261116);a.add_argument('--output',required=True);b=s.add_parser('analyze');b.add_argument('--key',required=True);b.add_argument('--responses',required=True);b.add_argument('--output',required=True);args=p.parse_args()
if args.mode=='prepare':
 if args.participants<1:p.error('participants must be positive')
 prepare(args)
else:analyze(args)
