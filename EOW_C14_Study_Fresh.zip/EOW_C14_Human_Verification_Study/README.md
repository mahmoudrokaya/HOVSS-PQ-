# EOW_C14 Human Verification Study — prospective protocol

**STATUS: NOT CONDUCTED.** No physical captures or human observations are available. This package generates blinded assignments and analyzes future, genuine responses; it does not simulate participants.

## Research questions

1. Can an unaided human observer recognize the intended image from physically superimposed original C13 transparency shares?
2. Can the observer distinguish valid aligned pairs from wrong-partner pairs and deliberately misregistered pairs?
3. What are accuracy, false acceptance rate (FAR), false rejection rate (FRR), recognition, confidence, and decision time?

## Materials

Use the eight original C13 image IDs 2018, 3063, 5096, 6046, 8068, 10081, 14085, 14092. Print original Share A and B PDFs at 100% actual size, without fit-to-page. Measure and record the 10 mm calibration bar. Use a fixed light box or diffuse white background, controlled illumination, viewing distance and time. Record printer, media, and actual registration offset in mm. The study script generates 3 conditions per image: `valid_aligned` (matching A+B), `wrong_partner` (A with B from a different image), and `misregistered` (matching A+B shifted by a measured predefined offset, e.g. one subpixel). The printed pairs must be physically prepared by study staff; the CSV does not make physical trials happen.

## Ethics and administration

Obtain institutional ethics approval or documented exemption before recruitment; obtain informed consent and permit withdrawal. Use pseudonymous participant IDs. Avoid personally identifying data. Default 12 participants × 24 trials = 288 planned observations is a **pilot planning choice**, not a powered sample size. Staff use the PRIVATE key and pair-setup CSV. Participants must not see condition labels, reference secrets or expected answers. Randomize order as assigned; avoid giving feedback. For each trial, ask: (a) Does this appear to be a valid properly reconstructed image? 1=yes, 0=no; (b) what image/object is recognized? free text; (c) confidence 1–5; (d) response time in seconds. Leave unanswered trials blank (missing, not a negative). Predefine the recognition scoring rubric and have independent blinded raters code free text.

## Windows PowerShell: prepare

From the folder containing `EOW_C14_Human_Verification_Study.py`:

```powershell
python EOW_C14_Human_Verification_Study.py prepare `
  --participants 12 `
  --seed 20261116 `
  --output "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C14_Human_Verification"
```

Outputs: `STAFF_RANDOMIZATION_KEY_PRIVATE.csv`, `STAFF_PAIR_SETUP.csv`, `PARTICIPANT_RESPONSES_BLINDED.csv`, `study_manifest.json`. Enter actual observations into the blinded CSV, never into the private key.

## Windows PowerShell: analyze

```powershell
python EOW_C14_Human_Verification_Study.py analyze `
  --key "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C14_Human_Verification\STAFF_RANDOMIZATION_KEY_PRIVATE.csv" `
  --responses "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C14_Human_Verification\PARTICIPANT_RESPONSES_BLINDED.csv" `
  --output "D:\48\481\New Papers\Nature_Idea\Experiments\Results\EOW_C14_Human_Verification\Analysis"
```

Produces `analysis_summary.json` and `analyzed_trials.csv`. FAR = invalid pairs accepted / invalid pairs answered. FRR = valid pairs rejected / valid pairs answered. Trial-level Wilson intervals are descriptive, because responses from the same participant are correlated. A confirmatory analysis should use participant-level resampling or hierarchical modeling, with prespecified outcomes and power analysis.

## Essential limitations

- Wrong-partner rejection demonstrates pair compatibility discrimination, **not detection of malicious tampering**.
- Misregistration rejection tests alignment usability, not cryptographic security.
- The cross-version C13 comparison used independently randomized masks and is confounded; it is not a controlled tamper condition.
- This study has no controlled same-mask tampering condition. That requires a separately designed fixed-Share-A test.
- No security qualification or human accuracy result is supported until actual participants and physical trials are recorded.

Reference: Naor and Shamir, Visual Cryptography, https://doi.org/10.1007/BFb0053419
