# EOW-C02 — Executable Security Games

Finite-domain width: **2 bits**. Self-tests: **8/8**.

## Privacy (one share + public witness)

- EOW1_full_reference: maximum pairwise TV = **1.0**.
- EOW2_separable_tag: maximum pairwise TV = **1.0**.
- EOW3_masked_challenge: maximum pairwise TV = **0.0**.

## Integrity (content-changing submissions)

- EOW1_full_reference: **0/3072** accepted under idealized verifier.
- EOW2_separable_tag: **3072/3072** accepted under idealized verifier.
- EOW3_masked_challenge: **0/3072** accepted under idealized verifier.

## Essential limits

- The tested verifiers are digital predicates, **not passive human optical checks**.
- No real ML-DSA signing or verification is performed.
- Exact-copy replay succeeds in all three static schemes.
- Protected verifier custody is essential to the masked-reference construction.
- A bounded, restricted adaptive oracle game does not establish general adaptive security.
- A failed finite-domain test is a valid counterexample; passing a finite-domain test is not a proof for arbitrary sizes.

**Verdict: NO_SECURITY_QUALIFIED_CONSTRUCTION.**

References: https://doi.org/10.1007/BFb0053419 ; https://doi.org/10.6028/NIST.FIPS.204
