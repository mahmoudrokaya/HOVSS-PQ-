# EOW_C10 — Full-Dataset OR-VSS Baseline Benchmark

- Decoded 554 / 1064 selected files (510 failures).
- Source-file SHA-256 duplicate extras: 10.
- Reconstructed correctly: 554.
- Total attack trials: 70912.
- Elapsed wall-clock time: 22.505 seconds.
- Peak Python tracemalloc allocation: 37784566 bytes (not full process RSS).

## Attack baseline

- exact_or: 35546/70912 accepted; empirical=0.501269178700361; Wilson 95% interval=[0.49758906565341743, 0.5049491542413036].
- black_count: 35546/70912 accepted; empirical=0.501269178700361; Wilson 95% interval=[0.49758906565341743, 0.5049491542413036].

The exact structural acceptance probability for the selected one-bit attack is 1/2 under the specified independent uniform mask. The empirical rate is a sampling diagnostic, not a proof of image-size-dependent security.

## Limitations

This is a resized binary-image baseline. It does not test physical transparency fabrication, registration, human perception, issuer verification, or general adversarial optimality. Input errors and duplicates are disclosed. The C07 privacy and C08 enrollment results are separate.

## References

- [Naor and Shamir — Visual Cryptography](https://doi.org/10.1007/BFb0053419)
- [NIST FIPS 204](https://doi.org/10.6028/NIST.FIPS.204)
