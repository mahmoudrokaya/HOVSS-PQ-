# EOW_C07 — Privacy–Integrity Feasibility Diagnostic

**Research verdict:** NO_SECURITY_QUALIFIED_CONSTRUCTION.
**Scope:** exact finite-domain computational experiment, not a universal impossibility theorem.

## Principal findings

- Public one-share privacy max TV: 0.
- Enrollment-exposure max TV: 0.984375.
- Worst optimal precommitted content-changing forgery probability: 0.5.
- Secret/pad/challenge enumerated exhaustively for the selected domain.
- Human verification and post-quantum issuer binding remain untested.

## Per-view information leakage

| Observer | View | I(S;V) bits | Max TV | MAP guess |
|---|---|---:|---:|---:|
| exact_or | public_A | 0 | 0 | 0.125 |
| exact_or | public_A_mask | 0 | 0 | 0.125 |
| exact_or | public_A_expected | 1.5 | 0.875 | 0.421875 |
| exact_or | public_A_mask_expected | 2.25 | 0.984375 | 0.669922 |
| exact_or | public_A_B | 3 | 1 | 1 |
| exact_or | B_only | 0 | 0 | 0.125 |
| exact_or | B_mask | 0 | 0 | 0.125 |
| exact_or | B_expected | 0 | 0 | 0.125 |
| exact_or | B_mask_expected | 0 | 0 | 0.125 |
| exact_or | A_B_mask_expected | 3 | 1 | 1 |
| black_count | public_A | 0 | 0 | 0.125 |
| black_count | public_A_mask | 0 | 0 | 0.125 |
| black_count | public_A_expected | 0 | 0 | 0.125 |
| black_count | public_A_mask_expected | 1.5 | 0.875 | 0.421875 |
| black_count | public_A_B | 3 | 1 | 1 |
| black_count | B_only | 0 | 0 | 0.125 |
| black_count | B_mask | 0 | 0 | 0.125 |
| black_count | B_expected | 0 | 0 | 0.125 |
| black_count | B_mask_expected | 0 | 0 | 0.125 |
| black_count | A_B_mask_expected | 3 | 1 | 1 |

## Interpretation

A protected witness may provide an ideal integrity comparison while its disclosure leaks the secret. An OR mask hides modified subpixels, creating content-changing collisions. These are conditional findings for the specified construction and exposure views.
An exact comparator is not evidence of unaided human optical authentication. Electronic ML-DSA enrollment does not by itself provide a passive optical issuer check.

## Sources

- [Naor and Shamir, Visual Cryptography](https://doi.org/10.1007/BFb0053419)
- [NIST FIPS 204, ML-DSA](https://doi.org/10.6028/NIST.FIPS.204)
