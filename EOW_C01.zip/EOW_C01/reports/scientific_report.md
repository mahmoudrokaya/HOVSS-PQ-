# EOW-C01 — Exact Small-Domain Construction Feasibility

**Verdict:** NO SECURITY-QUALIFIED CONSTRUCTION.

## Scope

Exhaustive 2-bit XOR secret-sharing toy models, not an optical fabrication experiment or a proof of post-quantum human verification.

## Models

- **EOW1:** exact protected copies of both shares; ideal equality check.
- **EOW2:** separable authentication tag, checked independently of share content (negative control).
- **EOW3:** one-time-pad masked enrolled share references, with protected keys and ideal XOR comparison.

## Exact findings

- **EOW1_full_reference:** public witness + one share max TV=1.0; compromised full witness + one share max TV=1.0; accepted content-changing presentations 0/3072.
- **EOW2_separable_tag:** public witness + one share max TV=1.0; compromised full witness + one share max TV=1.0; accepted content-changing presentations 3072/3072.
- **EOW3_masked_challenge:** public witness + one share max TV=0.0; compromised full witness + one share max TV=1.0; accepted content-changing presentations 0/3072.

- Binary OR: 4 outputs from 16 ordered input pairs, with 42 colliding unordered pairs of input pairs.

## Interpretation and limitations

1. EOW1's publicly observable full-share reference exposes both enrolled shares; this defeats secrecy.
2. EOW2's separable tag can be transplanted while data change.
3. EOW3's masked references can hide content in the defined public-witness view, but compromised protected keys expose the enrolled shares, and its verifier is a **digital XOR oracle**, not a demonstrated human-only optical comparator.
4. Exact copies pass; replay protection is absent.
5. The enumeration does not test ML-DSA, physical robustness, human detection, or adaptive-query security.

## Scientific references

- Naor and Shamir (1994), Visual Cryptography: https://doi.org/10.1007/BFb0053419
- NIST FIPS 204, ML-DSA: https://doi.org/10.6028/NIST.FIPS.204
