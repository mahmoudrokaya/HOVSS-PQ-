# HOVSS-PQ Experiments Directory Exploration

Root: `D:\48\481\New Papers\Nature_Idea\Experiments`
Generated (UTC): 2026-11-14T15:56:01.587606+00:00

- Files: **8,907**
- Directories: **605**
- Size: **2.272 GiB**
- SHA-256 duplicate groups: **126**
- Scan errors: **0**

## Categories

| Category | Files | Bytes |
|---|---:|---:|
| data | 1,493 | 1,635,829,403 |
| document | 572 | 476,823,252 |
| archive | 23 | 226,701,279 |
| image | 673 | 52,315,166 |
| other | 3,158 | 26,966,224 |
| code | 2,988 | 21,162,756 |

## F1–F8 path-based inventory

| Stage | Files | Code files |
|---|---:|---:|
| F1 | 26 | 1 |
| F2 | 27 | 2 |
| F3 | 39 | 1 |
| F4 | 21 | 1 |
| F5 | 36 | 1 |
| F6 | 37 | 1 |
| F7 | 32 | 1 |
| F8 | 1 | 1 |

## Largest files

- `Results/F7_Complete/reports/attacks_trials.csv` (728,223,145 bytes)
- `Results/F4_Complete/reports/attacks_trials.csv` (256,648,944 bytes)
- `Results/F6_Complete/reports/attacks_trials.csv` (192,179,754 bytes)
- `Results/F5_Complete/reports/attacks_trials.csv` (170,877,307 bytes)
- `Results/F2_Complete/reports/attacks_trials.csv` (120,271,278 bytes)
- `Data/BSR_bsds500.tar` (74,332,160 bytes)
- `Results/F3_Complete/reports/attacks_trials.csv` (52,719,888 bytes)
- `Results/F1_Complete/reports/attacks_trials.csv` (45,409,065 bytes)
- `Results/F7_Complete/F7_Complete.zip` (26,917,062 bytes)
- `Data/BSR/BSDS500/data/groundTruth.rar` (21,140,535 bytes)
- `Code/Literature/Literature_Math.zip` (20,629,833 bytes)
- `Code/Literature/Literature_Expanded/pdfs/ceb2485ae1ccce7c.pdf` (15,644,313 bytes)
- `Results/F4_Complete/F4_Complete.zip` (15,556,025 bytes)
- `Results/F6_Complete/F6_Complete.zip` (12,101,115 bytes)
- `Code/Literature/Literature_Expanded/pdfs/a681aa2640449209.pdf` (11,585,892 bytes)
- `Code/Literature/Literature_Expanded/pdfs/826120f926cfc06e.pdf` (10,904,672 bytes)
- `Data/BSR/documentation/Arbelaez_Maire_Fowlkes_Malik_TPAMI2010.pdf` (10,767,108 bytes)
- `Code/Literature/Literature_Expanded/pdfs/7b31263e8ef777b7.pdf` (10,429,725 bytes)
- `Code/Literature/Literature_Expanded/pdfs/f0f52c8cc96898f8.pdf` (10,429,725 bytes)
- `Data/BSR/documentation.rar` (10,309,791 bytes)
- `Code/Literature/Literature_Expanded/pdfs/9ebc5b29363375e5.pdf` (10,099,575 bytes)
- `Code/Literature/Literature_Expanded/pdfs/2163020a110d925f.pdf` (9,762,831 bytes)
- `Code/Literature/Literature_Expanded/pdfs/0055f58e4a18e4e5.pdf` (9,510,569 bytes)
- `Code/Literature/Literature_Expanded/pdfs/12eb6ff7cf7d1136.pdf` (9,428,889 bytes)
- `Code/Literature/Literature_Expanded/pdfs/77a2c315dae33c73.pdf` (9,350,668 bytes)
- `Data/misc.rar` (9,236,241 bytes)
- `Code/Literature/Literature_Expanded/pdfs/ee3592b883df5f05.pdf` (9,143,773 bytes)
- `Code/Literature/Literature_Expanded/pdfs/8ef325bc52dfdefd.pdf` (8,720,463 bytes)
- `Code/Literature/Literature_Expanded/pdfs/04e9504730008f88.pdf` (8,695,731 bytes)
- `Results/F2_Complete/F2_Complete.zip` (8,625,937 bytes)

## Important limitations

- Dataset counts are path-based candidates, not verified benchmark counts.
- Duplicate groups are complete only for files actually hashed.
- Files inside archives are not inspected.
- Code is inventoried but never executed or imported.
- Symlinks are not traversed.
